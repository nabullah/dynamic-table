/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef } from '@angular/core';
import { BaseDirective2, StyleBuilder, StyleDefinition, StyleUtils, MediaMarshaller, ElementMatcher } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export interface LayoutAlignParent {
    layout: string;
    inline: boolean;
}
export declare class LayoutAlignStyleBuilder extends StyleBuilder {
    buildStyles(align: string, parent: LayoutAlignParent): StyleDefinition;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<LayoutAlignStyleBuilder, never>;
}
/**
 * 'layout-align' flexbox styling directive
 *  Defines positioning of child elements along main and cross axis in a layout container
 *  Optional values: {main-axis} values or {main-axis cross-axis} value pairs
 *
 *  @see https://css-tricks.com/almanac/properties/j/justify-content/
 *  @see https://css-tricks.com/almanac/properties/a/align-items/
 *  @see https://css-tricks.com/almanac/properties/a/align-content/
 */
export declare class LayoutAlignDirective extends BaseDirective2 {
    protected DIRECTIVE_KEY: string;
    protected layout: string;
    protected inline: boolean;
    constructor(elRef: ElementRef, styleUtils: StyleUtils, styleBuilder: LayoutAlignStyleBuilder, marshal: MediaMarshaller);
    /**
     *
     */
    protected updateWithValue(value: string): void;
    /**
     * Cache the parent container 'flex-direction' and update the 'flex' styles
     */
    protected onLayoutChange(matcher: ElementMatcher): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<LayoutAlignDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<LayoutAlignDirective, never, never, {}, {}, never>;
}
export declare class DefaultLayoutAlignDirective extends LayoutAlignDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultLayoutAlignDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultLayoutAlignDirective, "  [fxLayoutAlign], [fxLayoutAlign.xs], [fxLayoutAlign.sm], [fxLayoutAlign.md],  [fxLayoutAlign.lg], [fxLayoutAlign.xl], [fxLayoutAlign.lt-sm], [fxLayoutAlign.lt-md],  [fxLayoutAlign.lt-lg], [fxLayoutAlign.lt-xl], [fxLayoutAlign.gt-xs], [fxLayoutAlign.gt-sm],  [fxLayoutAlign.gt-md], [fxLayoutAlign.gt-lg]", never, { "fxLayoutAlign": "fxLayoutAlign"; "fxLayoutAlign.xs": "fxLayoutAlign.xs"; "fxLayoutAlign.sm": "fxLayoutAlign.sm"; "fxLayoutAlign.md": "fxLayoutAlign.md"; "fxLayoutAlign.lg": "fxLayoutAlign.lg"; "fxLayoutAlign.xl": "fxLayoutAlign.xl"; "fxLayoutAlign.lt-sm": "fxLayoutAlign.lt-sm"; "fxLayoutAlign.lt-md": "fxLayoutAlign.lt-md"; "fxLayoutAlign.lt-lg": "fxLayoutAlign.lt-lg"; "fxLayoutAlign.lt-xl": "fxLayoutAlign.lt-xl"; "fxLayoutAlign.gt-xs": "fxLayoutAlign.gt-xs"; "fxLayoutAlign.gt-sm": "fxLayoutAlign.gt-sm"; "fxLayoutAlign.gt-md": "fxLayoutAlign.gt-md"; "fxLayoutAlign.gt-lg": "fxLayoutAlign.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGF5b3V0LWFsaWduLmQudHMiLCJzb3VyY2VzIjpbImxheW91dC1hbGlnbi5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBHb29nbGUgTExDIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9hbmd1bGFyLmlvL2xpY2Vuc2VcbiAqL1xuaW1wb3J0IHsgRWxlbWVudFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmFzZURpcmVjdGl2ZTIsIFN0eWxlQnVpbGRlciwgU3R5bGVEZWZpbml0aW9uLCBTdHlsZVV0aWxzLCBNZWRpYU1hcnNoYWxsZXIsIEVsZW1lbnRNYXRjaGVyIH0gZnJvbSAnQGFuZ3VsYXIvZmxleC1sYXlvdXQvY29yZSc7XG5leHBvcnQgaW50ZXJmYWNlIExheW91dEFsaWduUGFyZW50IHtcbiAgICBsYXlvdXQ6IHN0cmluZztcbiAgICBpbmxpbmU6IGJvb2xlYW47XG59XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBMYXlvdXRBbGlnblN0eWxlQnVpbGRlciBleHRlbmRzIFN0eWxlQnVpbGRlciB7XG4gICAgYnVpbGRTdHlsZXMoYWxpZ246IHN0cmluZywgcGFyZW50OiBMYXlvdXRBbGlnblBhcmVudCk6IFN0eWxlRGVmaW5pdGlvbjtcbn1cbi8qKlxuICogJ2xheW91dC1hbGlnbicgZmxleGJveCBzdHlsaW5nIGRpcmVjdGl2ZVxuICogIERlZmluZXMgcG9zaXRpb25pbmcgb2YgY2hpbGQgZWxlbWVudHMgYWxvbmcgbWFpbiBhbmQgY3Jvc3MgYXhpcyBpbiBhIGxheW91dCBjb250YWluZXJcbiAqICBPcHRpb25hbCB2YWx1ZXM6IHttYWluLWF4aXN9IHZhbHVlcyBvciB7bWFpbi1heGlzIGNyb3NzLWF4aXN9IHZhbHVlIHBhaXJzXG4gKlxuICogIEBzZWUgaHR0cHM6Ly9jc3MtdHJpY2tzLmNvbS9hbG1hbmFjL3Byb3BlcnRpZXMvai9qdXN0aWZ5LWNvbnRlbnQvXG4gKiAgQHNlZSBodHRwczovL2Nzcy10cmlja3MuY29tL2FsbWFuYWMvcHJvcGVydGllcy9hL2FsaWduLWl0ZW1zL1xuICogIEBzZWUgaHR0cHM6Ly9jc3MtdHJpY2tzLmNvbS9hbG1hbmFjL3Byb3BlcnRpZXMvYS9hbGlnbi1jb250ZW50L1xuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBMYXlvdXRBbGlnbkRpcmVjdGl2ZSBleHRlbmRzIEJhc2VEaXJlY3RpdmUyIHtcbiAgICBwcm90ZWN0ZWQgRElSRUNUSVZFX0tFWTogc3RyaW5nO1xuICAgIHByb3RlY3RlZCBsYXlvdXQ6IHN0cmluZztcbiAgICBwcm90ZWN0ZWQgaW5saW5lOiBib29sZWFuO1xuICAgIGNvbnN0cnVjdG9yKGVsUmVmOiBFbGVtZW50UmVmLCBzdHlsZVV0aWxzOiBTdHlsZVV0aWxzLCBzdHlsZUJ1aWxkZXI6IExheW91dEFsaWduU3R5bGVCdWlsZGVyLCBtYXJzaGFsOiBNZWRpYU1hcnNoYWxsZXIpO1xuICAgIC8qKlxuICAgICAqXG4gICAgICovXG4gICAgcHJvdGVjdGVkIHVwZGF0ZVdpdGhWYWx1ZSh2YWx1ZTogc3RyaW5nKTogdm9pZDtcbiAgICAvKipcbiAgICAgKiBDYWNoZSB0aGUgcGFyZW50IGNvbnRhaW5lciAnZmxleC1kaXJlY3Rpb24nIGFuZCB1cGRhdGUgdGhlICdmbGV4JyBzdHlsZXNcbiAgICAgKi9cbiAgICBwcm90ZWN0ZWQgb25MYXlvdXRDaGFuZ2UobWF0Y2hlcjogRWxlbWVudE1hdGNoZXIpOiB2b2lkO1xufVxuZXhwb3J0IGRlY2xhcmUgY2xhc3MgRGVmYXVsdExheW91dEFsaWduRGlyZWN0aXZlIGV4dGVuZHMgTGF5b3V0QWxpZ25EaXJlY3RpdmUge1xuICAgIHByb3RlY3RlZCBpbnB1dHM6IHN0cmluZ1tdO1xufVxuIl19
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef, OnChanges } from '@angular/core';
import { Directionality } from '@angular/cdk/bidi';
import { MediaMarshaller, BaseDirective2, StyleBuilder, StyleDefinition, StyleUtils } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export interface FlexOffsetParent {
    layout: string;
    isRtl: boolean;
}
export declare class FlexOffsetStyleBuilder extends StyleBuilder {
    buildStyles(offset: string, parent: FlexOffsetParent): StyleDefinition;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FlexOffsetStyleBuilder, never>;
}
/**
 * 'flex-offset' flexbox styling directive
 * Configures the 'margin-left' of the element in a layout container
 */
export declare class FlexOffsetDirective extends BaseDirective2 implements OnChanges {
    protected directionality: Directionality;
    protected DIRECTIVE_KEY: string;
    constructor(elRef: ElementRef, directionality: Directionality, styleBuilder: FlexOffsetStyleBuilder, marshal: MediaMarshaller, styler: StyleUtils);
    /**
     * Using the current fxFlexOffset value, update the inline CSS
     * NOTE: this will assign `margin-left` if the parent flex-direction == 'row',
     *       otherwise `margin-top` is used for the offset.
     */
    protected updateWithValue(value?: string | number): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FlexOffsetDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<FlexOffsetDirective, never, never, {}, {}, never>;
}
export declare class DefaultFlexOffsetDirective extends FlexOffsetDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultFlexOffsetDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultFlexOffsetDirective, "  [fxFlexOffset], [fxFlexOffset.xs], [fxFlexOffset.sm], [fxFlexOffset.md],  [fxFlexOffset.lg], [fxFlexOffset.xl], [fxFlexOffset.lt-sm], [fxFlexOffset.lt-md],  [fxFlexOffset.lt-lg], [fxFlexOffset.lt-xl], [fxFlexOffset.gt-xs], [fxFlexOffset.gt-sm],  [fxFlexOffset.gt-md], [fxFlexOffset.gt-lg]", never, { "fxFlexOffset": "fxFlexOffset"; "fxFlexOffset.xs": "fxFlexOffset.xs"; "fxFlexOffset.sm": "fxFlexOffset.sm"; "fxFlexOffset.md": "fxFlexOffset.md"; "fxFlexOffset.lg": "fxFlexOffset.lg"; "fxFlexOffset.xl": "fxFlexOffset.xl"; "fxFlexOffset.lt-sm": "fxFlexOffset.lt-sm"; "fxFlexOffset.lt-md": "fxFlexOffset.lt-md"; "fxFlexOffset.lt-lg": "fxFlexOffset.lt-lg"; "fxFlexOffset.lt-xl": "fxFlexOffset.lt-xl"; "fxFlexOffset.gt-xs": "fxFlexOffset.gt-xs"; "fxFlexOffset.gt-sm": "fxFlexOffset.gt-sm"; "fxFlexOffset.gt-md": "fxFlexOffset.gt-md"; "fxFlexOffset.gt-lg": "fxFlexOffset.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmxleC1vZmZzZXQuZC50cyIsInNvdXJjZXMiOlsiZmxleC1vZmZzZXQuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQ0E7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEdvb2dsZSBMTEMgQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2FuZ3VsYXIuaW8vbGljZW5zZVxuICovXG5pbXBvcnQgeyBFbGVtZW50UmVmLCBPbkNoYW5nZXMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IERpcmVjdGlvbmFsaXR5IH0gZnJvbSAnQGFuZ3VsYXIvY2RrL2JpZGknO1xuaW1wb3J0IHsgTWVkaWFNYXJzaGFsbGVyLCBCYXNlRGlyZWN0aXZlMiwgU3R5bGVCdWlsZGVyLCBTdHlsZURlZmluaXRpb24sIFN0eWxlVXRpbHMgfSBmcm9tICdAYW5ndWxhci9mbGV4LWxheW91dC9jb3JlJztcbmV4cG9ydCBpbnRlcmZhY2UgRmxleE9mZnNldFBhcmVudCB7XG4gICAgbGF5b3V0OiBzdHJpbmc7XG4gICAgaXNSdGw6IGJvb2xlYW47XG59XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBGbGV4T2Zmc2V0U3R5bGVCdWlsZGVyIGV4dGVuZHMgU3R5bGVCdWlsZGVyIHtcbiAgICBidWlsZFN0eWxlcyhvZmZzZXQ6IHN0cmluZywgcGFyZW50OiBGbGV4T2Zmc2V0UGFyZW50KTogU3R5bGVEZWZpbml0aW9uO1xufVxuLyoqXG4gKiAnZmxleC1vZmZzZXQnIGZsZXhib3ggc3R5bGluZyBkaXJlY3RpdmVcbiAqIENvbmZpZ3VyZXMgdGhlICdtYXJnaW4tbGVmdCcgb2YgdGhlIGVsZW1lbnQgaW4gYSBsYXlvdXQgY29udGFpbmVyXG4gKi9cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIEZsZXhPZmZzZXREaXJlY3RpdmUgZXh0ZW5kcyBCYXNlRGlyZWN0aXZlMiBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XG4gICAgcHJvdGVjdGVkIGRpcmVjdGlvbmFsaXR5OiBEaXJlY3Rpb25hbGl0eTtcbiAgICBwcm90ZWN0ZWQgRElSRUNUSVZFX0tFWTogc3RyaW5nO1xuICAgIGNvbnN0cnVjdG9yKGVsUmVmOiBFbGVtZW50UmVmLCBkaXJlY3Rpb25hbGl0eTogRGlyZWN0aW9uYWxpdHksIHN0eWxlQnVpbGRlcjogRmxleE9mZnNldFN0eWxlQnVpbGRlciwgbWFyc2hhbDogTWVkaWFNYXJzaGFsbGVyLCBzdHlsZXI6IFN0eWxlVXRpbHMpO1xuICAgIC8qKlxuICAgICAqIFVzaW5nIHRoZSBjdXJyZW50IGZ4RmxleE9mZnNldCB2YWx1ZSwgdXBkYXRlIHRoZSBpbmxpbmUgQ1NTXG4gICAgICogTk9URTogdGhpcyB3aWxsIGFzc2lnbiBgbWFyZ2luLWxlZnRgIGlmIHRoZSBwYXJlbnQgZmxleC1kaXJlY3Rpb24gPT0gJ3JvdycsXG4gICAgICogICAgICAgb3RoZXJ3aXNlIGBtYXJnaW4tdG9wYCBpcyB1c2VkIGZvciB0aGUgb2Zmc2V0LlxuICAgICAqL1xuICAgIHByb3RlY3RlZCB1cGRhdGVXaXRoVmFsdWUodmFsdWU/OiBzdHJpbmcgfCBudW1iZXIpOiB2b2lkO1xufVxuZXhwb3J0IGRlY2xhcmUgY2xhc3MgRGVmYXVsdEZsZXhPZmZzZXREaXJlY3RpdmUgZXh0ZW5kcyBGbGV4T2Zmc2V0RGlyZWN0aXZlIHtcbiAgICBwcm90ZWN0ZWQgaW5wdXRzOiBzdHJpbmdbXTtcbn1cbiJdfQ==
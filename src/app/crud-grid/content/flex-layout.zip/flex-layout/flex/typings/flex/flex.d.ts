/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef, OnInit } from '@angular/core';
import { BaseDirective2, LayoutConfigOptions, StyleUtils, StyleBuilder, StyleDefinition, MediaMarshaller, ElementMatcher } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
interface FlexBuilderParent {
    direction: string;
    hasWrap: boolean;
}
export declare class FlexStyleBuilder extends StyleBuilder {
    protected layoutConfig: LayoutConfigOptions;
    constructor(layoutConfig: LayoutConfigOptions);
    buildStyles(input: string, parent: FlexBuilderParent): StyleDefinition;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FlexStyleBuilder, never>;
}
/**
 * Directive to control the size of a flex item using flex-basis, flex-grow, and flex-shrink.
 * Corresponds to the css `flex` shorthand property.
 *
 * @see https://css-tricks.com/snippets/css/a-guide-to-flexbox/
 */
export declare class FlexDirective extends BaseDirective2 implements OnInit {
    protected layoutConfig: LayoutConfigOptions;
    protected marshal: MediaMarshaller;
    protected DIRECTIVE_KEY: string;
    protected direction?: string;
    protected wrap?: boolean;
    get shrink(): string;
    set shrink(value: string);
    get grow(): string;
    set grow(value: string);
    protected flexGrow: string;
    protected flexShrink: string;
    constructor(elRef: ElementRef, styleUtils: StyleUtils, layoutConfig: LayoutConfigOptions, styleBuilder: FlexStyleBuilder, marshal: MediaMarshaller);
    ngOnInit(): void;
    /**
     * Caches the parent container's 'flex-direction' and updates the element's style.
     * Used as a handler for layout change events from the parent flex container.
     */
    protected onLayoutChange(matcher: ElementMatcher): void;
    /** Input to this is exclusively the basis input value */
    protected updateWithValue(value: string): void;
    /** Trigger a style reflow, usually based on a shrink/grow input event */
    protected triggerReflow(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FlexDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<FlexDirective, never, never, { "shrink": "fxShrink"; "grow": "fxGrow"; }, {}, never>;
}
export declare class DefaultFlexDirective extends FlexDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultFlexDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultFlexDirective, "  [fxFlex], [fxFlex.xs], [fxFlex.sm], [fxFlex.md],  [fxFlex.lg], [fxFlex.xl], [fxFlex.lt-sm], [fxFlex.lt-md],  [fxFlex.lt-lg], [fxFlex.lt-xl], [fxFlex.gt-xs], [fxFlex.gt-sm],  [fxFlex.gt-md], [fxFlex.gt-lg]", never, { "fxFlex": "fxFlex"; "fxFlex.xs": "fxFlex.xs"; "fxFlex.sm": "fxFlex.sm"; "fxFlex.md": "fxFlex.md"; "fxFlex.lg": "fxFlex.lg"; "fxFlex.xl": "fxFlex.xl"; "fxFlex.lt-sm": "fxFlex.lt-sm"; "fxFlex.lt-md": "fxFlex.lt-md"; "fxFlex.lt-lg": "fxFlex.lt-lg"; "fxFlex.lt-xl": "fxFlex.lt-xl"; "fxFlex.gt-xs": "fxFlex.gt-xs"; "fxFlex.gt-sm": "fxFlex.gt-sm"; "fxFlex.gt-md": "fxFlex.gt-md"; "fxFlex.gt-lg": "fxFlex.gt-lg"; }, {}, never>;
}
export {};

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmxleC5kLnRzIiwic291cmNlcyI6WyJmbGV4LmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgR29vZ2xlIExMQyBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vYW5ndWxhci5pby9saWNlbnNlXG4gKi9cbmltcG9ydCB7IEVsZW1lbnRSZWYsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmFzZURpcmVjdGl2ZTIsIExheW91dENvbmZpZ09wdGlvbnMsIFN0eWxlVXRpbHMsIFN0eWxlQnVpbGRlciwgU3R5bGVEZWZpbml0aW9uLCBNZWRpYU1hcnNoYWxsZXIsIEVsZW1lbnRNYXRjaGVyIH0gZnJvbSAnQGFuZ3VsYXIvZmxleC1sYXlvdXQvY29yZSc7XG5pbnRlcmZhY2UgRmxleEJ1aWxkZXJQYXJlbnQge1xuICAgIGRpcmVjdGlvbjogc3RyaW5nO1xuICAgIGhhc1dyYXA6IGJvb2xlYW47XG59XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBGbGV4U3R5bGVCdWlsZGVyIGV4dGVuZHMgU3R5bGVCdWlsZGVyIHtcbiAgICBwcm90ZWN0ZWQgbGF5b3V0Q29uZmlnOiBMYXlvdXRDb25maWdPcHRpb25zO1xuICAgIGNvbnN0cnVjdG9yKGxheW91dENvbmZpZzogTGF5b3V0Q29uZmlnT3B0aW9ucyk7XG4gICAgYnVpbGRTdHlsZXMoaW5wdXQ6IHN0cmluZywgcGFyZW50OiBGbGV4QnVpbGRlclBhcmVudCk6IFN0eWxlRGVmaW5pdGlvbjtcbn1cbi8qKlxuICogRGlyZWN0aXZlIHRvIGNvbnRyb2wgdGhlIHNpemUgb2YgYSBmbGV4IGl0ZW0gdXNpbmcgZmxleC1iYXNpcywgZmxleC1ncm93LCBhbmQgZmxleC1zaHJpbmsuXG4gKiBDb3JyZXNwb25kcyB0byB0aGUgY3NzIGBmbGV4YCBzaG9ydGhhbmQgcHJvcGVydHkuXG4gKlxuICogQHNlZSBodHRwczovL2Nzcy10cmlja3MuY29tL3NuaXBwZXRzL2Nzcy9hLWd1aWRlLXRvLWZsZXhib3gvXG4gKi9cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIEZsZXhEaXJlY3RpdmUgZXh0ZW5kcyBCYXNlRGlyZWN0aXZlMiBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gICAgcHJvdGVjdGVkIGxheW91dENvbmZpZzogTGF5b3V0Q29uZmlnT3B0aW9ucztcbiAgICBwcm90ZWN0ZWQgbWFyc2hhbDogTWVkaWFNYXJzaGFsbGVyO1xuICAgIHByb3RlY3RlZCBESVJFQ1RJVkVfS0VZOiBzdHJpbmc7XG4gICAgcHJvdGVjdGVkIGRpcmVjdGlvbj86IHN0cmluZztcbiAgICBwcm90ZWN0ZWQgd3JhcD86IGJvb2xlYW47XG4gICAgZ2V0IHNocmluaygpOiBzdHJpbmc7XG4gICAgc2V0IHNocmluayh2YWx1ZTogc3RyaW5nKTtcbiAgICBnZXQgZ3JvdygpOiBzdHJpbmc7XG4gICAgc2V0IGdyb3codmFsdWU6IHN0cmluZyk7XG4gICAgcHJvdGVjdGVkIGZsZXhHcm93OiBzdHJpbmc7XG4gICAgcHJvdGVjdGVkIGZsZXhTaHJpbms6IHN0cmluZztcbiAgICBjb25zdHJ1Y3RvcihlbFJlZjogRWxlbWVudFJlZiwgc3R5bGVVdGlsczogU3R5bGVVdGlscywgbGF5b3V0Q29uZmlnOiBMYXlvdXRDb25maWdPcHRpb25zLCBzdHlsZUJ1aWxkZXI6IEZsZXhTdHlsZUJ1aWxkZXIsIG1hcnNoYWw6IE1lZGlhTWFyc2hhbGxlcik7XG4gICAgbmdPbkluaXQoKTogdm9pZDtcbiAgICAvKipcbiAgICAgKiBDYWNoZXMgdGhlIHBhcmVudCBjb250YWluZXIncyAnZmxleC1kaXJlY3Rpb24nIGFuZCB1cGRhdGVzIHRoZSBlbGVtZW50J3Mgc3R5bGUuXG4gICAgICogVXNlZCBhcyBhIGhhbmRsZXIgZm9yIGxheW91dCBjaGFuZ2UgZXZlbnRzIGZyb20gdGhlIHBhcmVudCBmbGV4IGNvbnRhaW5lci5cbiAgICAgKi9cbiAgICBwcm90ZWN0ZWQgb25MYXlvdXRDaGFuZ2UobWF0Y2hlcjogRWxlbWVudE1hdGNoZXIpOiB2b2lkO1xuICAgIC8qKiBJbnB1dCB0byB0aGlzIGlzIGV4Y2x1c2l2ZWx5IHRoZSBiYXNpcyBpbnB1dCB2YWx1ZSAqL1xuICAgIHByb3RlY3RlZCB1cGRhdGVXaXRoVmFsdWUodmFsdWU6IHN0cmluZyk6IHZvaWQ7XG4gICAgLyoqIFRyaWdnZXIgYSBzdHlsZSByZWZsb3csIHVzdWFsbHkgYmFzZWQgb24gYSBzaHJpbmsvZ3JvdyBpbnB1dCBldmVudCAqL1xuICAgIHByb3RlY3RlZCB0cmlnZ2VyUmVmbG93KCk6IHZvaWQ7XG59XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBEZWZhdWx0RmxleERpcmVjdGl2ZSBleHRlbmRzIEZsZXhEaXJlY3RpdmUge1xuICAgIHByb3RlY3RlZCBpbnB1dHM6IHN0cmluZ1tdO1xufVxuZXhwb3J0IHt9O1xuIl19
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef, OnDestroy, NgZone, AfterContentInit } from '@angular/core';
import { Directionality } from '@angular/cdk/bidi';
import { BaseDirective2, StyleBuilder, StyleDefinition, StyleUtils, MediaMarshaller, ElementMatcher } from 'src/app/crud-grid/content/flex-layout/core';
import { Subject } from 'rxjs';
import * as ɵngcc0 from '@angular/core';
export interface LayoutGapParent {
    directionality: string;
    items: HTMLElement[];
    layout: string;
}
export declare class LayoutGapStyleBuilder extends StyleBuilder {
    private _styler;
    constructor(_styler: StyleUtils);
    buildStyles(gapValue: string, parent: LayoutGapParent): StyleDefinition;
    sideEffect(gapValue: string, _styles: StyleDefinition, parent: LayoutGapParent): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<LayoutGapStyleBuilder, never>;
}
/**
 * 'layout-padding' styling directive
 *  Defines padding of child elements in a layout container
 */
export declare class LayoutGapDirective extends BaseDirective2 implements AfterContentInit, OnDestroy {
    protected zone: NgZone;
    protected directionality: Directionality;
    protected styleUtils: StyleUtils;
    protected layout: string;
    protected DIRECTIVE_KEY: string;
    protected observerSubject: Subject<void>;
    /** Special accessor to query for all child 'element' nodes regardless of type, class, etc */
    protected get childrenNodes(): HTMLElement[];
    constructor(elRef: ElementRef, zone: NgZone, directionality: Directionality, styleUtils: StyleUtils, styleBuilder: LayoutGapStyleBuilder, marshal: MediaMarshaller);
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    /**
     * Cache the parent container 'flex-direction' and update the 'margin' styles
     */
    protected onLayoutChange(matcher: ElementMatcher): void;
    /**
     *
     */
    protected updateWithValue(value: string): void;
    /** We need to override clearStyles because in most cases mru isn't populated */
    protected clearStyles(): void;
    /** Determine if an element will show or hide based on current activation */
    protected willDisplay(source: HTMLElement): boolean;
    protected buildChildObservable(): void;
    protected observer?: MutationObserver;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<LayoutGapDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<LayoutGapDirective, never, never, {}, {}, never>;
}
export declare class DefaultLayoutGapDirective extends LayoutGapDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultLayoutGapDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultLayoutGapDirective, "  [fxLayoutGap], [fxLayoutGap.xs], [fxLayoutGap.sm], [fxLayoutGap.md],  [fxLayoutGap.lg], [fxLayoutGap.xl], [fxLayoutGap.lt-sm], [fxLayoutGap.lt-md],  [fxLayoutGap.lt-lg], [fxLayoutGap.lt-xl], [fxLayoutGap.gt-xs], [fxLayoutGap.gt-sm],  [fxLayoutGap.gt-md], [fxLayoutGap.gt-lg]", never, { "fxLayoutGap": "fxLayoutGap"; "fxLayoutGap.xs": "fxLayoutGap.xs"; "fxLayoutGap.sm": "fxLayoutGap.sm"; "fxLayoutGap.md": "fxLayoutGap.md"; "fxLayoutGap.lg": "fxLayoutGap.lg"; "fxLayoutGap.xl": "fxLayoutGap.xl"; "fxLayoutGap.lt-sm": "fxLayoutGap.lt-sm"; "fxLayoutGap.lt-md": "fxLayoutGap.lt-md"; "fxLayoutGap.lt-lg": "fxLayoutGap.lt-lg"; "fxLayoutGap.lt-xl": "fxLayoutGap.lt-xl"; "fxLayoutGap.gt-xs": "fxLayoutGap.gt-xs"; "fxLayoutGap.gt-sm": "fxLayoutGap.gt-sm"; "fxLayoutGap.gt-md": "fxLayoutGap.gt-md"; "fxLayoutGap.gt-lg": "fxLayoutGap.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGF5b3V0LWdhcC5kLnRzIiwic291cmNlcyI6WyJsYXlvdXQtZ2FwLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBHb29nbGUgTExDIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9hbmd1bGFyLmlvL2xpY2Vuc2VcbiAqL1xuaW1wb3J0IHsgRWxlbWVudFJlZiwgT25EZXN0cm95LCBOZ1pvbmUsIEFmdGVyQ29udGVudEluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IERpcmVjdGlvbmFsaXR5IH0gZnJvbSAnQGFuZ3VsYXIvY2RrL2JpZGknO1xuaW1wb3J0IHsgQmFzZURpcmVjdGl2ZTIsIFN0eWxlQnVpbGRlciwgU3R5bGVEZWZpbml0aW9uLCBTdHlsZVV0aWxzLCBNZWRpYU1hcnNoYWxsZXIsIEVsZW1lbnRNYXRjaGVyIH0gZnJvbSAnQGFuZ3VsYXIvZmxleC1sYXlvdXQvY29yZSc7XG5pbXBvcnQgeyBTdWJqZWN0IH0gZnJvbSAncnhqcyc7XG5leHBvcnQgaW50ZXJmYWNlIExheW91dEdhcFBhcmVudCB7XG4gICAgZGlyZWN0aW9uYWxpdHk6IHN0cmluZztcbiAgICBpdGVtczogSFRNTEVsZW1lbnRbXTtcbiAgICBsYXlvdXQ6IHN0cmluZztcbn1cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIExheW91dEdhcFN0eWxlQnVpbGRlciBleHRlbmRzIFN0eWxlQnVpbGRlciB7XG4gICAgcHJpdmF0ZSBfc3R5bGVyO1xuICAgIGNvbnN0cnVjdG9yKF9zdHlsZXI6IFN0eWxlVXRpbHMpO1xuICAgIGJ1aWxkU3R5bGVzKGdhcFZhbHVlOiBzdHJpbmcsIHBhcmVudDogTGF5b3V0R2FwUGFyZW50KTogU3R5bGVEZWZpbml0aW9uO1xuICAgIHNpZGVFZmZlY3QoZ2FwVmFsdWU6IHN0cmluZywgX3N0eWxlczogU3R5bGVEZWZpbml0aW9uLCBwYXJlbnQ6IExheW91dEdhcFBhcmVudCk6IHZvaWQ7XG59XG4vKipcbiAqICdsYXlvdXQtcGFkZGluZycgc3R5bGluZyBkaXJlY3RpdmVcbiAqICBEZWZpbmVzIHBhZGRpbmcgb2YgY2hpbGQgZWxlbWVudHMgaW4gYSBsYXlvdXQgY29udGFpbmVyXG4gKi9cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIExheW91dEdhcERpcmVjdGl2ZSBleHRlbmRzIEJhc2VEaXJlY3RpdmUyIGltcGxlbWVudHMgQWZ0ZXJDb250ZW50SW5pdCwgT25EZXN0cm95IHtcbiAgICBwcm90ZWN0ZWQgem9uZTogTmdab25lO1xuICAgIHByb3RlY3RlZCBkaXJlY3Rpb25hbGl0eTogRGlyZWN0aW9uYWxpdHk7XG4gICAgcHJvdGVjdGVkIHN0eWxlVXRpbHM6IFN0eWxlVXRpbHM7XG4gICAgcHJvdGVjdGVkIGxheW91dDogc3RyaW5nO1xuICAgIHByb3RlY3RlZCBESVJFQ1RJVkVfS0VZOiBzdHJpbmc7XG4gICAgcHJvdGVjdGVkIG9ic2VydmVyU3ViamVjdDogU3ViamVjdDx2b2lkPjtcbiAgICAvKiogU3BlY2lhbCBhY2Nlc3NvciB0byBxdWVyeSBmb3IgYWxsIGNoaWxkICdlbGVtZW50JyBub2RlcyByZWdhcmRsZXNzIG9mIHR5cGUsIGNsYXNzLCBldGMgKi9cbiAgICBwcm90ZWN0ZWQgZ2V0IGNoaWxkcmVuTm9kZXMoKTogSFRNTEVsZW1lbnRbXTtcbiAgICBjb25zdHJ1Y3RvcihlbFJlZjogRWxlbWVudFJlZiwgem9uZTogTmdab25lLCBkaXJlY3Rpb25hbGl0eTogRGlyZWN0aW9uYWxpdHksIHN0eWxlVXRpbHM6IFN0eWxlVXRpbHMsIHN0eWxlQnVpbGRlcjogTGF5b3V0R2FwU3R5bGVCdWlsZGVyLCBtYXJzaGFsOiBNZWRpYU1hcnNoYWxsZXIpO1xuICAgIG5nQWZ0ZXJDb250ZW50SW5pdCgpOiB2b2lkO1xuICAgIG5nT25EZXN0cm95KCk6IHZvaWQ7XG4gICAgLyoqXG4gICAgICogQ2FjaGUgdGhlIHBhcmVudCBjb250YWluZXIgJ2ZsZXgtZGlyZWN0aW9uJyBhbmQgdXBkYXRlIHRoZSAnbWFyZ2luJyBzdHlsZXNcbiAgICAgKi9cbiAgICBwcm90ZWN0ZWQgb25MYXlvdXRDaGFuZ2UobWF0Y2hlcjogRWxlbWVudE1hdGNoZXIpOiB2b2lkO1xuICAgIC8qKlxuICAgICAqXG4gICAgICovXG4gICAgcHJvdGVjdGVkIHVwZGF0ZVdpdGhWYWx1ZSh2YWx1ZTogc3RyaW5nKTogdm9pZDtcbiAgICAvKiogV2UgbmVlZCB0byBvdmVycmlkZSBjbGVhclN0eWxlcyBiZWNhdXNlIGluIG1vc3QgY2FzZXMgbXJ1IGlzbid0IHBvcHVsYXRlZCAqL1xuICAgIHByb3RlY3RlZCBjbGVhclN0eWxlcygpOiB2b2lkO1xuICAgIC8qKiBEZXRlcm1pbmUgaWYgYW4gZWxlbWVudCB3aWxsIHNob3cgb3IgaGlkZSBiYXNlZCBvbiBjdXJyZW50IGFjdGl2YXRpb24gKi9cbiAgICBwcm90ZWN0ZWQgd2lsbERpc3BsYXkoc291cmNlOiBIVE1MRWxlbWVudCk6IGJvb2xlYW47XG4gICAgcHJvdGVjdGVkIGJ1aWxkQ2hpbGRPYnNlcnZhYmxlKCk6IHZvaWQ7XG4gICAgcHJvdGVjdGVkIG9ic2VydmVyPzogTXV0YXRpb25PYnNlcnZlcjtcbn1cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIERlZmF1bHRMYXlvdXRHYXBEaXJlY3RpdmUgZXh0ZW5kcyBMYXlvdXRHYXBEaXJlY3RpdmUge1xuICAgIHByb3RlY3RlZCBpbnB1dHM6IHN0cmluZ1tdO1xufVxuIl19
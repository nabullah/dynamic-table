/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef } from '@angular/core';
import { BaseDirective2, StyleBuilder, StyleDefinition, StyleUtils, MediaMarshaller } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export declare class FlexFillStyleBuilder extends StyleBuilder {
    buildStyles(_input: string): {
        margin: number;
        width: string;
        height: string;
        'min-width': string;
        'min-height': string;
    };
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FlexFillStyleBuilder, never>;
}
/**
 * 'fxFill' flexbox styling directive
 *  Maximizes width and height of element in a layout container
 *
 *  NOTE: fxFill is NOT responsive API!!
 */
export declare class FlexFillDirective extends BaseDirective2 {
    constructor(elRef: ElementRef, styleUtils: StyleUtils, styleBuilder: FlexFillStyleBuilder, marshal: MediaMarshaller);
    protected styleCache: Map<string, StyleDefinition>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FlexFillDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<FlexFillDirective, "[fxFill], [fxFlexFill]", never, {}, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmxleC1maWxsLmQudHMiLCJzb3VyY2VzIjpbImZsZXgtZmlsbC5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBHb29nbGUgTExDIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9hbmd1bGFyLmlvL2xpY2Vuc2VcbiAqL1xuaW1wb3J0IHsgRWxlbWVudFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmFzZURpcmVjdGl2ZTIsIFN0eWxlQnVpbGRlciwgU3R5bGVEZWZpbml0aW9uLCBTdHlsZVV0aWxzLCBNZWRpYU1hcnNoYWxsZXIgfSBmcm9tICdAYW5ndWxhci9mbGV4LWxheW91dC9jb3JlJztcbmV4cG9ydCBkZWNsYXJlIGNsYXNzIEZsZXhGaWxsU3R5bGVCdWlsZGVyIGV4dGVuZHMgU3R5bGVCdWlsZGVyIHtcbiAgICBidWlsZFN0eWxlcyhfaW5wdXQ6IHN0cmluZyk6IHtcbiAgICAgICAgbWFyZ2luOiBudW1iZXI7XG4gICAgICAgIHdpZHRoOiBzdHJpbmc7XG4gICAgICAgIGhlaWdodDogc3RyaW5nO1xuICAgICAgICAnbWluLXdpZHRoJzogc3RyaW5nO1xuICAgICAgICAnbWluLWhlaWdodCc6IHN0cmluZztcbiAgICB9O1xufVxuLyoqXG4gKiAnZnhGaWxsJyBmbGV4Ym94IHN0eWxpbmcgZGlyZWN0aXZlXG4gKiAgTWF4aW1pemVzIHdpZHRoIGFuZCBoZWlnaHQgb2YgZWxlbWVudCBpbiBhIGxheW91dCBjb250YWluZXJcbiAqXG4gKiAgTk9URTogZnhGaWxsIGlzIE5PVCByZXNwb25zaXZlIEFQSSEhXG4gKi9cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIEZsZXhGaWxsRGlyZWN0aXZlIGV4dGVuZHMgQmFzZURpcmVjdGl2ZTIge1xuICAgIGNvbnN0cnVjdG9yKGVsUmVmOiBFbGVtZW50UmVmLCBzdHlsZVV0aWxzOiBTdHlsZVV0aWxzLCBzdHlsZUJ1aWxkZXI6IEZsZXhGaWxsU3R5bGVCdWlsZGVyLCBtYXJzaGFsOiBNZWRpYU1hcnNoYWxsZXIpO1xuICAgIHByb3RlY3RlZCBzdHlsZUNhY2hlOiBNYXA8c3RyaW5nLCBTdHlsZURlZmluaXRpb24+O1xufVxuIl19
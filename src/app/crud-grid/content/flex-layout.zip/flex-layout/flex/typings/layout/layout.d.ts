/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef, OnChanges } from '@angular/core';
import { BaseDirective2, StyleBuilder, StyleDefinition, StyleUtils, MediaMarshaller } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export declare class LayoutStyleBuilder extends StyleBuilder {
    buildStyles(input: string): {
        display: string;
        'box-sizing': string;
        'flex-direction': string;
        'flex-wrap': string | null;
    };
    static ɵfac: ɵngcc0.ɵɵFactoryDef<LayoutStyleBuilder, never>;
}
/**
 * 'layout' flexbox styling directive
 * Defines the positioning flow direction for the child elements: row or column
 * Optional values: column or row (default)
 * @see https://css-tricks.com/almanac/properties/f/flex-direction/
 *
 */
export declare class LayoutDirective extends BaseDirective2 implements OnChanges {
    protected DIRECTIVE_KEY: string;
    constructor(elRef: ElementRef, styleUtils: StyleUtils, styleBuilder: LayoutStyleBuilder, marshal: MediaMarshaller);
    protected styleCache: Map<string, StyleDefinition>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<LayoutDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<LayoutDirective, never, never, {}, {}, never>;
}
export declare class DefaultLayoutDirective extends LayoutDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultLayoutDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultLayoutDirective, "  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],  [fxLayout.gt-md], [fxLayout.gt-lg]", never, { "fxLayout": "fxLayout"; "fxLayout.xs": "fxLayout.xs"; "fxLayout.sm": "fxLayout.sm"; "fxLayout.md": "fxLayout.md"; "fxLayout.lg": "fxLayout.lg"; "fxLayout.xl": "fxLayout.xl"; "fxLayout.lt-sm": "fxLayout.lt-sm"; "fxLayout.lt-md": "fxLayout.lt-md"; "fxLayout.lt-lg": "fxLayout.lt-lg"; "fxLayout.lt-xl": "fxLayout.lt-xl"; "fxLayout.gt-xs": "fxLayout.gt-xs"; "fxLayout.gt-sm": "fxLayout.gt-sm"; "fxLayout.gt-md": "fxLayout.gt-md"; "fxLayout.gt-lg": "fxLayout.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGF5b3V0LmQudHMiLCJzb3VyY2VzIjpbImxheW91dC5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgR29vZ2xlIExMQyBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vYW5ndWxhci5pby9saWNlbnNlXG4gKi9cbmltcG9ydCB7IEVsZW1lbnRSZWYsIE9uQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmFzZURpcmVjdGl2ZTIsIFN0eWxlQnVpbGRlciwgU3R5bGVEZWZpbml0aW9uLCBTdHlsZVV0aWxzLCBNZWRpYU1hcnNoYWxsZXIgfSBmcm9tICdAYW5ndWxhci9mbGV4LWxheW91dC9jb3JlJztcbmV4cG9ydCBkZWNsYXJlIGNsYXNzIExheW91dFN0eWxlQnVpbGRlciBleHRlbmRzIFN0eWxlQnVpbGRlciB7XG4gICAgYnVpbGRTdHlsZXMoaW5wdXQ6IHN0cmluZyk6IHtcbiAgICAgICAgZGlzcGxheTogc3RyaW5nO1xuICAgICAgICAnYm94LXNpemluZyc6IHN0cmluZztcbiAgICAgICAgJ2ZsZXgtZGlyZWN0aW9uJzogc3RyaW5nO1xuICAgICAgICAnZmxleC13cmFwJzogc3RyaW5nIHwgbnVsbDtcbiAgICB9O1xufVxuLyoqXG4gKiAnbGF5b3V0JyBmbGV4Ym94IHN0eWxpbmcgZGlyZWN0aXZlXG4gKiBEZWZpbmVzIHRoZSBwb3NpdGlvbmluZyBmbG93IGRpcmVjdGlvbiBmb3IgdGhlIGNoaWxkIGVsZW1lbnRzOiByb3cgb3IgY29sdW1uXG4gKiBPcHRpb25hbCB2YWx1ZXM6IGNvbHVtbiBvciByb3cgKGRlZmF1bHQpXG4gKiBAc2VlIGh0dHBzOi8vY3NzLXRyaWNrcy5jb20vYWxtYW5hYy9wcm9wZXJ0aWVzL2YvZmxleC1kaXJlY3Rpb24vXG4gKlxuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBMYXlvdXREaXJlY3RpdmUgZXh0ZW5kcyBCYXNlRGlyZWN0aXZlMiBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XG4gICAgcHJvdGVjdGVkIERJUkVDVElWRV9LRVk6IHN0cmluZztcbiAgICBjb25zdHJ1Y3RvcihlbFJlZjogRWxlbWVudFJlZiwgc3R5bGVVdGlsczogU3R5bGVVdGlscywgc3R5bGVCdWlsZGVyOiBMYXlvdXRTdHlsZUJ1aWxkZXIsIG1hcnNoYWw6IE1lZGlhTWFyc2hhbGxlcik7XG4gICAgcHJvdGVjdGVkIHN0eWxlQ2FjaGU6IE1hcDxzdHJpbmcsIFN0eWxlRGVmaW5pdGlvbj47XG59XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBEZWZhdWx0TGF5b3V0RGlyZWN0aXZlIGV4dGVuZHMgTGF5b3V0RGlyZWN0aXZlIHtcbiAgICBwcm90ZWN0ZWQgaW5wdXRzOiBzdHJpbmdbXTtcbn1cbiJdfQ==
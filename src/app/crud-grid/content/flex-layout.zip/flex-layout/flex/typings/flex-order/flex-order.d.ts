/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef, OnChanges } from '@angular/core';
import { BaseDirective2, StyleBuilder, StyleDefinition, StyleUtils, MediaMarshaller } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export declare class FlexOrderStyleBuilder extends StyleBuilder {
    buildStyles(value: string): {
        order: string | number;
    };
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FlexOrderStyleBuilder, never>;
}
/**
 * 'flex-order' flexbox styling directive
 * Configures the positional ordering of the element in a sorted layout container
 * @see https://css-tricks.com/almanac/properties/o/order/
 */
export declare class FlexOrderDirective extends BaseDirective2 implements OnChanges {
    protected DIRECTIVE_KEY: string;
    constructor(elRef: ElementRef, styleUtils: StyleUtils, styleBuilder: FlexOrderStyleBuilder, marshal: MediaMarshaller);
    protected styleCache: Map<string, StyleDefinition>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FlexOrderDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<FlexOrderDirective, never, never, {}, {}, never>;
}
export declare class DefaultFlexOrderDirective extends FlexOrderDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultFlexOrderDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultFlexOrderDirective, "  [fxFlexOrder], [fxFlexOrder.xs], [fxFlexOrder.sm], [fxFlexOrder.md],  [fxFlexOrder.lg], [fxFlexOrder.xl], [fxFlexOrder.lt-sm], [fxFlexOrder.lt-md],  [fxFlexOrder.lt-lg], [fxFlexOrder.lt-xl], [fxFlexOrder.gt-xs], [fxFlexOrder.gt-sm],  [fxFlexOrder.gt-md], [fxFlexOrder.gt-lg]", never, { "fxFlexOrder": "fxFlexOrder"; "fxFlexOrder.xs": "fxFlexOrder.xs"; "fxFlexOrder.sm": "fxFlexOrder.sm"; "fxFlexOrder.md": "fxFlexOrder.md"; "fxFlexOrder.lg": "fxFlexOrder.lg"; "fxFlexOrder.xl": "fxFlexOrder.xl"; "fxFlexOrder.lt-sm": "fxFlexOrder.lt-sm"; "fxFlexOrder.lt-md": "fxFlexOrder.lt-md"; "fxFlexOrder.lt-lg": "fxFlexOrder.lt-lg"; "fxFlexOrder.lt-xl": "fxFlexOrder.lt-xl"; "fxFlexOrder.gt-xs": "fxFlexOrder.gt-xs"; "fxFlexOrder.gt-sm": "fxFlexOrder.gt-sm"; "fxFlexOrder.gt-md": "fxFlexOrder.gt-md"; "fxFlexOrder.gt-lg": "fxFlexOrder.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmxleC1vcmRlci5kLnRzIiwic291cmNlcyI6WyJmbGV4LW9yZGVyLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQ0E7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEdvb2dsZSBMTEMgQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2FuZ3VsYXIuaW8vbGljZW5zZVxuICovXG5pbXBvcnQgeyBFbGVtZW50UmVmLCBPbkNoYW5nZXMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEJhc2VEaXJlY3RpdmUyLCBTdHlsZUJ1aWxkZXIsIFN0eWxlRGVmaW5pdGlvbiwgU3R5bGVVdGlscywgTWVkaWFNYXJzaGFsbGVyIH0gZnJvbSAnQGFuZ3VsYXIvZmxleC1sYXlvdXQvY29yZSc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBGbGV4T3JkZXJTdHlsZUJ1aWxkZXIgZXh0ZW5kcyBTdHlsZUJ1aWxkZXIge1xuICAgIGJ1aWxkU3R5bGVzKHZhbHVlOiBzdHJpbmcpOiB7XG4gICAgICAgIG9yZGVyOiBzdHJpbmcgfCBudW1iZXI7XG4gICAgfTtcbn1cbi8qKlxuICogJ2ZsZXgtb3JkZXInIGZsZXhib3ggc3R5bGluZyBkaXJlY3RpdmVcbiAqIENvbmZpZ3VyZXMgdGhlIHBvc2l0aW9uYWwgb3JkZXJpbmcgb2YgdGhlIGVsZW1lbnQgaW4gYSBzb3J0ZWQgbGF5b3V0IGNvbnRhaW5lclxuICogQHNlZSBodHRwczovL2Nzcy10cmlja3MuY29tL2FsbWFuYWMvcHJvcGVydGllcy9vL29yZGVyL1xuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBGbGV4T3JkZXJEaXJlY3RpdmUgZXh0ZW5kcyBCYXNlRGlyZWN0aXZlMiBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XG4gICAgcHJvdGVjdGVkIERJUkVDVElWRV9LRVk6IHN0cmluZztcbiAgICBjb25zdHJ1Y3RvcihlbFJlZjogRWxlbWVudFJlZiwgc3R5bGVVdGlsczogU3R5bGVVdGlscywgc3R5bGVCdWlsZGVyOiBGbGV4T3JkZXJTdHlsZUJ1aWxkZXIsIG1hcnNoYWw6IE1lZGlhTWFyc2hhbGxlcik7XG4gICAgcHJvdGVjdGVkIHN0eWxlQ2FjaGU6IE1hcDxzdHJpbmcsIFN0eWxlRGVmaW5pdGlvbj47XG59XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBEZWZhdWx0RmxleE9yZGVyRGlyZWN0aXZlIGV4dGVuZHMgRmxleE9yZGVyRGlyZWN0aXZlIHtcbiAgICBwcm90ZWN0ZWQgaW5wdXRzOiBzdHJpbmdbXTtcbn1cbiJdfQ==
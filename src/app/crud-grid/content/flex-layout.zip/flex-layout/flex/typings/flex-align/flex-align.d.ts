/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef } from '@angular/core';
import { MediaMarshaller, BaseDirective2, StyleBuilder, StyleDefinition, StyleUtils } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export declare class FlexAlignStyleBuilder extends StyleBuilder {
    buildStyles(input: string): StyleDefinition;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FlexAlignStyleBuilder, never>;
}
/**
 * 'flex-align' flexbox styling directive
 * Allows element-specific overrides for cross-axis alignments in a layout container
 * @see https://css-tricks.com/almanac/properties/a/align-self/
 */
export declare class FlexAlignDirective extends BaseDirective2 {
    protected DIRECTIVE_KEY: string;
    constructor(elRef: ElementRef, styleUtils: StyleUtils, styleBuilder: FlexAlignStyleBuilder, marshal: MediaMarshaller);
    protected styleCache: Map<string, StyleDefinition>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FlexAlignDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<FlexAlignDirective, never, never, {}, {}, never>;
}
export declare class DefaultFlexAlignDirective extends FlexAlignDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultFlexAlignDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultFlexAlignDirective, "  [fxFlexAlign], [fxFlexAlign.xs], [fxFlexAlign.sm], [fxFlexAlign.md],  [fxFlexAlign.lg], [fxFlexAlign.xl], [fxFlexAlign.lt-sm], [fxFlexAlign.lt-md],  [fxFlexAlign.lt-lg], [fxFlexAlign.lt-xl], [fxFlexAlign.gt-xs], [fxFlexAlign.gt-sm],  [fxFlexAlign.gt-md], [fxFlexAlign.gt-lg]", never, { "fxFlexAlign": "fxFlexAlign"; "fxFlexAlign.xs": "fxFlexAlign.xs"; "fxFlexAlign.sm": "fxFlexAlign.sm"; "fxFlexAlign.md": "fxFlexAlign.md"; "fxFlexAlign.lg": "fxFlexAlign.lg"; "fxFlexAlign.xl": "fxFlexAlign.xl"; "fxFlexAlign.lt-sm": "fxFlexAlign.lt-sm"; "fxFlexAlign.lt-md": "fxFlexAlign.lt-md"; "fxFlexAlign.lt-lg": "fxFlexAlign.lt-lg"; "fxFlexAlign.lt-xl": "fxFlexAlign.lt-xl"; "fxFlexAlign.gt-xs": "fxFlexAlign.gt-xs"; "fxFlexAlign.gt-sm": "fxFlexAlign.gt-sm"; "fxFlexAlign.gt-md": "fxFlexAlign.gt-md"; "fxFlexAlign.gt-lg": "fxFlexAlign.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmxleC1hbGlnbi5kLnRzIiwic291cmNlcyI6WyJmbGV4LWFsaWduLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgR29vZ2xlIExMQyBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vYW5ndWxhci5pby9saWNlbnNlXG4gKi9cbmltcG9ydCB7IEVsZW1lbnRSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE1lZGlhTWFyc2hhbGxlciwgQmFzZURpcmVjdGl2ZTIsIFN0eWxlQnVpbGRlciwgU3R5bGVEZWZpbml0aW9uLCBTdHlsZVV0aWxzIH0gZnJvbSAnQGFuZ3VsYXIvZmxleC1sYXlvdXQvY29yZSc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBGbGV4QWxpZ25TdHlsZUJ1aWxkZXIgZXh0ZW5kcyBTdHlsZUJ1aWxkZXIge1xuICAgIGJ1aWxkU3R5bGVzKGlucHV0OiBzdHJpbmcpOiBTdHlsZURlZmluaXRpb247XG59XG4vKipcbiAqICdmbGV4LWFsaWduJyBmbGV4Ym94IHN0eWxpbmcgZGlyZWN0aXZlXG4gKiBBbGxvd3MgZWxlbWVudC1zcGVjaWZpYyBvdmVycmlkZXMgZm9yIGNyb3NzLWF4aXMgYWxpZ25tZW50cyBpbiBhIGxheW91dCBjb250YWluZXJcbiAqIEBzZWUgaHR0cHM6Ly9jc3MtdHJpY2tzLmNvbS9hbG1hbmFjL3Byb3BlcnRpZXMvYS9hbGlnbi1zZWxmL1xuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBGbGV4QWxpZ25EaXJlY3RpdmUgZXh0ZW5kcyBCYXNlRGlyZWN0aXZlMiB7XG4gICAgcHJvdGVjdGVkIERJUkVDVElWRV9LRVk6IHN0cmluZztcbiAgICBjb25zdHJ1Y3RvcihlbFJlZjogRWxlbWVudFJlZiwgc3R5bGVVdGlsczogU3R5bGVVdGlscywgc3R5bGVCdWlsZGVyOiBGbGV4QWxpZ25TdHlsZUJ1aWxkZXIsIG1hcnNoYWw6IE1lZGlhTWFyc2hhbGxlcik7XG4gICAgcHJvdGVjdGVkIHN0eWxlQ2FjaGU6IE1hcDxzdHJpbmcsIFN0eWxlRGVmaW5pdGlvbj47XG59XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBEZWZhdWx0RmxleEFsaWduRGlyZWN0aXZlIGV4dGVuZHMgRmxleEFsaWduRGlyZWN0aXZlIHtcbiAgICBwcm90ZWN0ZWQgaW5wdXRzOiBzdHJpbmdbXTtcbn1cbiJdfQ==
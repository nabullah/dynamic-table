/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef } from '@angular/core';
import { BaseDirective2, StyleUtils, MediaMarshaller, StyleBuilder } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export interface GridGapParent {
    inline: boolean;
}
export declare class GridGapStyleBuilder extends StyleBuilder {
    buildStyles(input: string, parent: GridGapParent): {
        display: string;
        'grid-gap': string;
    };
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridGapStyleBuilder, never>;
}
export declare class GridGapDirective extends BaseDirective2 {
    protected DIRECTIVE_KEY: string;
    get inline(): boolean;
    set inline(val: boolean);
    protected _inline: boolean;
    constructor(elRef: ElementRef, styleUtils: StyleUtils, styleBuilder: GridGapStyleBuilder, marshal: MediaMarshaller);
    protected updateWithValue(value: string): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridGapDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<GridGapDirective, never, never, { "inline": "gdInline"; }, {}, never>;
}
/**
 * 'grid-gap' CSS Grid styling directive
 * Configures the gap between items in the grid
 * Syntax: <row gap> [<column-gap>]
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-17
 */
export declare class DefaultGridGapDirective extends GridGapDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultGridGapDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultGridGapDirective, "  [gdGap],  [gdGap.xs], [gdGap.sm], [gdGap.md], [gdGap.lg], [gdGap.xl],  [gdGap.lt-sm], [gdGap.lt-md], [gdGap.lt-lg], [gdGap.lt-xl],  [gdGap.gt-xs], [gdGap.gt-sm], [gdGap.gt-md], [gdGap.gt-lg]", never, { "gdGap": "gdGap"; "gdGap.xs": "gdGap.xs"; "gdGap.sm": "gdGap.sm"; "gdGap.md": "gdGap.md"; "gdGap.lg": "gdGap.lg"; "gdGap.xl": "gdGap.xl"; "gdGap.lt-sm": "gdGap.lt-sm"; "gdGap.lt-md": "gdGap.lt-md"; "gdGap.lt-lg": "gdGap.lt-lg"; "gdGap.lt-xl": "gdGap.lt-xl"; "gdGap.gt-xs": "gdGap.gt-xs"; "gdGap.gt-sm": "gdGap.gt-sm"; "gdGap.gt-md": "gdGap.gt-md"; "gdGap.gt-lg": "gdGap.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2FwLmQudHMiLCJzb3VyY2VzIjpbImdhcC5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgR29vZ2xlIExMQyBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vYW5ndWxhci5pby9saWNlbnNlXG4gKi9cbmltcG9ydCB7IEVsZW1lbnRSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEJhc2VEaXJlY3RpdmUyLCBTdHlsZVV0aWxzLCBNZWRpYU1hcnNoYWxsZXIsIFN0eWxlQnVpbGRlciB9IGZyb20gJ0Bhbmd1bGFyL2ZsZXgtbGF5b3V0L2NvcmUnO1xuZXhwb3J0IGludGVyZmFjZSBHcmlkR2FwUGFyZW50IHtcbiAgICBpbmxpbmU6IGJvb2xlYW47XG59XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBHcmlkR2FwU3R5bGVCdWlsZGVyIGV4dGVuZHMgU3R5bGVCdWlsZGVyIHtcbiAgICBidWlsZFN0eWxlcyhpbnB1dDogc3RyaW5nLCBwYXJlbnQ6IEdyaWRHYXBQYXJlbnQpOiB7XG4gICAgICAgIGRpc3BsYXk6IHN0cmluZztcbiAgICAgICAgJ2dyaWQtZ2FwJzogc3RyaW5nO1xuICAgIH07XG59XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBHcmlkR2FwRGlyZWN0aXZlIGV4dGVuZHMgQmFzZURpcmVjdGl2ZTIge1xuICAgIHByb3RlY3RlZCBESVJFQ1RJVkVfS0VZOiBzdHJpbmc7XG4gICAgZ2V0IGlubGluZSgpOiBib29sZWFuO1xuICAgIHNldCBpbmxpbmUodmFsOiBib29sZWFuKTtcbiAgICBwcm90ZWN0ZWQgX2lubGluZTogYm9vbGVhbjtcbiAgICBjb25zdHJ1Y3RvcihlbFJlZjogRWxlbWVudFJlZiwgc3R5bGVVdGlsczogU3R5bGVVdGlscywgc3R5bGVCdWlsZGVyOiBHcmlkR2FwU3R5bGVCdWlsZGVyLCBtYXJzaGFsOiBNZWRpYU1hcnNoYWxsZXIpO1xuICAgIHByb3RlY3RlZCB1cGRhdGVXaXRoVmFsdWUodmFsdWU6IHN0cmluZyk6IHZvaWQ7XG59XG4vKipcbiAqICdncmlkLWdhcCcgQ1NTIEdyaWQgc3R5bGluZyBkaXJlY3RpdmVcbiAqIENvbmZpZ3VyZXMgdGhlIGdhcCBiZXR3ZWVuIGl0ZW1zIGluIHRoZSBncmlkXG4gKiBTeW50YXg6IDxyb3cgZ2FwPiBbPGNvbHVtbi1nYXA+XVxuICogQHNlZSBodHRwczovL2Nzcy10cmlja3MuY29tL3NuaXBwZXRzL2Nzcy9jb21wbGV0ZS1ndWlkZS1ncmlkLyNhcnRpY2xlLWhlYWRlci1pZC0xN1xuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBEZWZhdWx0R3JpZEdhcERpcmVjdGl2ZSBleHRlbmRzIEdyaWRHYXBEaXJlY3RpdmUge1xuICAgIHByb3RlY3RlZCBpbnB1dHM6IHN0cmluZ1tdO1xufVxuIl19
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef } from '@angular/core';
import { BaseDirective2, StyleUtils, StyleBuilder, MediaMarshaller } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export interface GridAutoParent {
    inline: boolean;
}
export declare class GridAutoStyleBuilder extends StyleBuilder {
    buildStyles(input: string, parent: GridAutoParent): {
        display: string;
        'grid-auto-flow': string;
    };
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridAutoStyleBuilder, never>;
}
export declare class GridAutoDirective extends BaseDirective2 {
    get inline(): boolean;
    set inline(val: boolean);
    protected _inline: boolean;
    protected DIRECTIVE_KEY: string;
    constructor(elementRef: ElementRef, styleBuilder: GridAutoStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller);
    protected updateWithValue(value: string): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridAutoDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<GridAutoDirective, never, never, { "inline": "gdInline"; }, {}, never>;
}
/**
 * 'grid-auto-flow' CSS Grid styling directive
 * Configures the auto placement algorithm for the grid
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-23
 */
export declare class DefaultGridAutoDirective extends GridAutoDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultGridAutoDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultGridAutoDirective, "  [gdAuto],  [gdAuto.xs], [gdAuto.sm], [gdAuto.md], [gdAuto.lg], [gdAuto.xl],  [gdAuto.lt-sm], [gdAuto.lt-md], [gdAuto.lt-lg], [gdAuto.lt-xl],  [gdAuto.gt-xs], [gdAuto.gt-sm], [gdAuto.gt-md], [gdAuto.gt-lg]", never, { "gdAuto": "gdAuto"; "gdAuto.xs": "gdAuto.xs"; "gdAuto.sm": "gdAuto.sm"; "gdAuto.md": "gdAuto.md"; "gdAuto.lg": "gdAuto.lg"; "gdAuto.xl": "gdAuto.xl"; "gdAuto.lt-sm": "gdAuto.lt-sm"; "gdAuto.lt-md": "gdAuto.lt-md"; "gdAuto.lt-lg": "gdAuto.lt-lg"; "gdAuto.lt-xl": "gdAuto.lt-xl"; "gdAuto.gt-xs": "gdAuto.gt-xs"; "gdAuto.gt-sm": "gdAuto.gt-sm"; "gdAuto.gt-md": "gdAuto.gt-md"; "gdAuto.gt-lg": "gdAuto.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXV0by5kLnRzIiwic291cmNlcyI6WyJhdXRvLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgR29vZ2xlIExMQyBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vYW5ndWxhci5pby9saWNlbnNlXG4gKi9cbmltcG9ydCB7IEVsZW1lbnRSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEJhc2VEaXJlY3RpdmUyLCBTdHlsZVV0aWxzLCBTdHlsZUJ1aWxkZXIsIE1lZGlhTWFyc2hhbGxlciB9IGZyb20gJ0Bhbmd1bGFyL2ZsZXgtbGF5b3V0L2NvcmUnO1xuZXhwb3J0IGludGVyZmFjZSBHcmlkQXV0b1BhcmVudCB7XG4gICAgaW5saW5lOiBib29sZWFuO1xufVxuZXhwb3J0IGRlY2xhcmUgY2xhc3MgR3JpZEF1dG9TdHlsZUJ1aWxkZXIgZXh0ZW5kcyBTdHlsZUJ1aWxkZXIge1xuICAgIGJ1aWxkU3R5bGVzKGlucHV0OiBzdHJpbmcsIHBhcmVudDogR3JpZEF1dG9QYXJlbnQpOiB7XG4gICAgICAgIGRpc3BsYXk6IHN0cmluZztcbiAgICAgICAgJ2dyaWQtYXV0by1mbG93Jzogc3RyaW5nO1xuICAgIH07XG59XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBHcmlkQXV0b0RpcmVjdGl2ZSBleHRlbmRzIEJhc2VEaXJlY3RpdmUyIHtcbiAgICBnZXQgaW5saW5lKCk6IGJvb2xlYW47XG4gICAgc2V0IGlubGluZSh2YWw6IGJvb2xlYW4pO1xuICAgIHByb3RlY3RlZCBfaW5saW5lOiBib29sZWFuO1xuICAgIHByb3RlY3RlZCBESVJFQ1RJVkVfS0VZOiBzdHJpbmc7XG4gICAgY29uc3RydWN0b3IoZWxlbWVudFJlZjogRWxlbWVudFJlZiwgc3R5bGVCdWlsZGVyOiBHcmlkQXV0b1N0eWxlQnVpbGRlciwgc3R5bGVyOiBTdHlsZVV0aWxzLCBtYXJzaGFsOiBNZWRpYU1hcnNoYWxsZXIpO1xuICAgIHByb3RlY3RlZCB1cGRhdGVXaXRoVmFsdWUodmFsdWU6IHN0cmluZyk6IHZvaWQ7XG59XG4vKipcbiAqICdncmlkLWF1dG8tZmxvdycgQ1NTIEdyaWQgc3R5bGluZyBkaXJlY3RpdmVcbiAqIENvbmZpZ3VyZXMgdGhlIGF1dG8gcGxhY2VtZW50IGFsZ29yaXRobSBmb3IgdGhlIGdyaWRcbiAqIEBzZWUgaHR0cHM6Ly9jc3MtdHJpY2tzLmNvbS9zbmlwcGV0cy9jc3MvY29tcGxldGUtZ3VpZGUtZ3JpZC8jYXJ0aWNsZS1oZWFkZXItaWQtMjNcbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgRGVmYXVsdEdyaWRBdXRvRGlyZWN0aXZlIGV4dGVuZHMgR3JpZEF1dG9EaXJlY3RpdmUge1xuICAgIHByb3RlY3RlZCBpbnB1dHM6IHN0cmluZ1tdO1xufVxuIl19
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef } from '@angular/core';
import { MediaMarshaller, BaseDirective2, StyleBuilder, StyleDefinition, StyleUtils } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export declare class GridAlignStyleBuilder extends StyleBuilder {
    buildStyles(input: string): {
        [key: string]: string;
    };
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridAlignStyleBuilder, never>;
}
export declare class GridAlignDirective extends BaseDirective2 {
    protected DIRECTIVE_KEY: string;
    constructor(elementRef: ElementRef, styleBuilder: GridAlignStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller);
    protected styleCache: Map<string, StyleDefinition>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridAlignDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<GridAlignDirective, never, never, {}, {}, never>;
}
/**
 * 'align' CSS Grid styling directive for grid children
 *  Defines positioning of child elements along row and column axis in a grid container
 *  Optional values: {row-axis} values or {row-axis column-axis} value pairs
 *
 *  @see https://css-tricks.com/snippets/css/complete-guide-grid/#prop-justify-self
 *  @see https://css-tricks.com/snippets/css/complete-guide-grid/#prop-align-self
 */
export declare class DefaultGridAlignDirective extends GridAlignDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultGridAlignDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultGridAlignDirective, "  [gdGridAlign],  [gdGridAlign.xs], [gdGridAlign.sm], [gdGridAlign.md], [gdGridAlign.lg],[gdGridAlign.xl],  [gdGridAlign.lt-sm], [gdGridAlign.lt-md], [gdGridAlign.lt-lg], [gdGridAlign.lt-xl],  [gdGridAlign.gt-xs], [gdGridAlign.gt-sm], [gdGridAlign.gt-md], [gdGridAlign.gt-lg]", never, { "gdGridAlign": "gdGridAlign"; "gdGridAlign.xs": "gdGridAlign.xs"; "gdGridAlign.sm": "gdGridAlign.sm"; "gdGridAlign.md": "gdGridAlign.md"; "gdGridAlign.lg": "gdGridAlign.lg"; "gdGridAlign.xl": "gdGridAlign.xl"; "gdGridAlign.lt-sm": "gdGridAlign.lt-sm"; "gdGridAlign.lt-md": "gdGridAlign.lt-md"; "gdGridAlign.lt-lg": "gdGridAlign.lt-lg"; "gdGridAlign.lt-xl": "gdGridAlign.lt-xl"; "gdGridAlign.gt-xs": "gdGridAlign.gt-xs"; "gdGridAlign.gt-sm": "gdGridAlign.gt-sm"; "gdGridAlign.gt-md": "gdGridAlign.gt-md"; "gdGridAlign.gt-lg": "gdGridAlign.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JpZC1hbGlnbi5kLnRzIiwic291cmNlcyI6WyJncmlkLWFsaWduLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEdvb2dsZSBMTEMgQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2FuZ3VsYXIuaW8vbGljZW5zZVxuICovXG5pbXBvcnQgeyBFbGVtZW50UmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBNZWRpYU1hcnNoYWxsZXIsIEJhc2VEaXJlY3RpdmUyLCBTdHlsZUJ1aWxkZXIsIFN0eWxlRGVmaW5pdGlvbiwgU3R5bGVVdGlscyB9IGZyb20gJ0Bhbmd1bGFyL2ZsZXgtbGF5b3V0L2NvcmUnO1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgR3JpZEFsaWduU3R5bGVCdWlsZGVyIGV4dGVuZHMgU3R5bGVCdWlsZGVyIHtcbiAgICBidWlsZFN0eWxlcyhpbnB1dDogc3RyaW5nKToge1xuICAgICAgICBba2V5OiBzdHJpbmddOiBzdHJpbmc7XG4gICAgfTtcbn1cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIEdyaWRBbGlnbkRpcmVjdGl2ZSBleHRlbmRzIEJhc2VEaXJlY3RpdmUyIHtcbiAgICBwcm90ZWN0ZWQgRElSRUNUSVZFX0tFWTogc3RyaW5nO1xuICAgIGNvbnN0cnVjdG9yKGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsIHN0eWxlQnVpbGRlcjogR3JpZEFsaWduU3R5bGVCdWlsZGVyLCBzdHlsZXI6IFN0eWxlVXRpbHMsIG1hcnNoYWw6IE1lZGlhTWFyc2hhbGxlcik7XG4gICAgcHJvdGVjdGVkIHN0eWxlQ2FjaGU6IE1hcDxzdHJpbmcsIFN0eWxlRGVmaW5pdGlvbj47XG59XG4vKipcbiAqICdhbGlnbicgQ1NTIEdyaWQgc3R5bGluZyBkaXJlY3RpdmUgZm9yIGdyaWQgY2hpbGRyZW5cbiAqICBEZWZpbmVzIHBvc2l0aW9uaW5nIG9mIGNoaWxkIGVsZW1lbnRzIGFsb25nIHJvdyBhbmQgY29sdW1uIGF4aXMgaW4gYSBncmlkIGNvbnRhaW5lclxuICogIE9wdGlvbmFsIHZhbHVlczoge3Jvdy1heGlzfSB2YWx1ZXMgb3Ige3Jvdy1heGlzIGNvbHVtbi1heGlzfSB2YWx1ZSBwYWlyc1xuICpcbiAqICBAc2VlIGh0dHBzOi8vY3NzLXRyaWNrcy5jb20vc25pcHBldHMvY3NzL2NvbXBsZXRlLWd1aWRlLWdyaWQvI3Byb3AtanVzdGlmeS1zZWxmXG4gKiAgQHNlZSBodHRwczovL2Nzcy10cmlja3MuY29tL3NuaXBwZXRzL2Nzcy9jb21wbGV0ZS1ndWlkZS1ncmlkLyNwcm9wLWFsaWduLXNlbGZcbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgRGVmYXVsdEdyaWRBbGlnbkRpcmVjdGl2ZSBleHRlbmRzIEdyaWRBbGlnbkRpcmVjdGl2ZSB7XG4gICAgcHJvdGVjdGVkIGlucHV0czogc3RyaW5nW107XG59XG4iXX0=
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef } from '@angular/core';
import { BaseDirective2, StyleUtils, StyleBuilder, StyleDefinition, MediaMarshaller } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export interface GridAlignColumnsParent {
    inline: boolean;
}
export declare class GridAlignColumnsStyleBuilder extends StyleBuilder {
    buildStyles(input: string, parent: GridAlignColumnsParent): StyleDefinition;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridAlignColumnsStyleBuilder, never>;
}
export declare class GridAlignColumnsDirective extends BaseDirective2 {
    protected DIRECTIVE_KEY: string;
    get inline(): boolean;
    set inline(val: boolean);
    protected _inline: boolean;
    constructor(elementRef: ElementRef, styleBuilder: GridAlignColumnsStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller);
    protected updateWithValue(value: string): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridAlignColumnsDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<GridAlignColumnsDirective, never, never, { "inline": "gdInline"; }, {}, never>;
}
/**
 * 'column alignment' CSS Grid styling directive
 * Configures the alignment in the column direction
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-19
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-21
 */
export declare class DefaultGridAlignColumnsDirective extends GridAlignColumnsDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultGridAlignColumnsDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultGridAlignColumnsDirective, "  [gdAlignColumns],  [gdAlignColumns.xs], [gdAlignColumns.sm], [gdAlignColumns.md],  [gdAlignColumns.lg], [gdAlignColumns.xl], [gdAlignColumns.lt-sm],  [gdAlignColumns.lt-md], [gdAlignColumns.lt-lg], [gdAlignColumns.lt-xl],  [gdAlignColumns.gt-xs], [gdAlignColumns.gt-sm], [gdAlignColumns.gt-md],  [gdAlignColumns.gt-lg]", never, { "gdAlignColumns": "gdAlignColumns"; "gdAlignColumns.xs": "gdAlignColumns.xs"; "gdAlignColumns.sm": "gdAlignColumns.sm"; "gdAlignColumns.md": "gdAlignColumns.md"; "gdAlignColumns.lg": "gdAlignColumns.lg"; "gdAlignColumns.xl": "gdAlignColumns.xl"; "gdAlignColumns.lt-sm": "gdAlignColumns.lt-sm"; "gdAlignColumns.lt-md": "gdAlignColumns.lt-md"; "gdAlignColumns.lt-lg": "gdAlignColumns.lt-lg"; "gdAlignColumns.lt-xl": "gdAlignColumns.lt-xl"; "gdAlignColumns.gt-xs": "gdAlignColumns.gt-xs"; "gdAlignColumns.gt-sm": "gdAlignColumns.gt-sm"; "gdAlignColumns.gt-md": "gdAlignColumns.gt-md"; "gdAlignColumns.gt-lg": "gdAlignColumns.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWxpZ24tY29sdW1ucy5kLnRzIiwic291cmNlcyI6WyJhbGlnbi1jb2x1bW5zLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBHb29nbGUgTExDIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9hbmd1bGFyLmlvL2xpY2Vuc2VcbiAqL1xuaW1wb3J0IHsgRWxlbWVudFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmFzZURpcmVjdGl2ZTIsIFN0eWxlVXRpbHMsIFN0eWxlQnVpbGRlciwgU3R5bGVEZWZpbml0aW9uLCBNZWRpYU1hcnNoYWxsZXIgfSBmcm9tICdAYW5ndWxhci9mbGV4LWxheW91dC9jb3JlJztcbmV4cG9ydCBpbnRlcmZhY2UgR3JpZEFsaWduQ29sdW1uc1BhcmVudCB7XG4gICAgaW5saW5lOiBib29sZWFuO1xufVxuZXhwb3J0IGRlY2xhcmUgY2xhc3MgR3JpZEFsaWduQ29sdW1uc1N0eWxlQnVpbGRlciBleHRlbmRzIFN0eWxlQnVpbGRlciB7XG4gICAgYnVpbGRTdHlsZXMoaW5wdXQ6IHN0cmluZywgcGFyZW50OiBHcmlkQWxpZ25Db2x1bW5zUGFyZW50KTogU3R5bGVEZWZpbml0aW9uO1xufVxuZXhwb3J0IGRlY2xhcmUgY2xhc3MgR3JpZEFsaWduQ29sdW1uc0RpcmVjdGl2ZSBleHRlbmRzIEJhc2VEaXJlY3RpdmUyIHtcbiAgICBwcm90ZWN0ZWQgRElSRUNUSVZFX0tFWTogc3RyaW5nO1xuICAgIGdldCBpbmxpbmUoKTogYm9vbGVhbjtcbiAgICBzZXQgaW5saW5lKHZhbDogYm9vbGVhbik7XG4gICAgcHJvdGVjdGVkIF9pbmxpbmU6IGJvb2xlYW47XG4gICAgY29uc3RydWN0b3IoZWxlbWVudFJlZjogRWxlbWVudFJlZiwgc3R5bGVCdWlsZGVyOiBHcmlkQWxpZ25Db2x1bW5zU3R5bGVCdWlsZGVyLCBzdHlsZXI6IFN0eWxlVXRpbHMsIG1hcnNoYWw6IE1lZGlhTWFyc2hhbGxlcik7XG4gICAgcHJvdGVjdGVkIHVwZGF0ZVdpdGhWYWx1ZSh2YWx1ZTogc3RyaW5nKTogdm9pZDtcbn1cbi8qKlxuICogJ2NvbHVtbiBhbGlnbm1lbnQnIENTUyBHcmlkIHN0eWxpbmcgZGlyZWN0aXZlXG4gKiBDb25maWd1cmVzIHRoZSBhbGlnbm1lbnQgaW4gdGhlIGNvbHVtbiBkaXJlY3Rpb25cbiAqIEBzZWUgaHR0cHM6Ly9jc3MtdHJpY2tzLmNvbS9zbmlwcGV0cy9jc3MvY29tcGxldGUtZ3VpZGUtZ3JpZC8jYXJ0aWNsZS1oZWFkZXItaWQtMTlcbiAqIEBzZWUgaHR0cHM6Ly9jc3MtdHJpY2tzLmNvbS9zbmlwcGV0cy9jc3MvY29tcGxldGUtZ3VpZGUtZ3JpZC8jYXJ0aWNsZS1oZWFkZXItaWQtMjFcbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgRGVmYXVsdEdyaWRBbGlnbkNvbHVtbnNEaXJlY3RpdmUgZXh0ZW5kcyBHcmlkQWxpZ25Db2x1bW5zRGlyZWN0aXZlIHtcbiAgICBwcm90ZWN0ZWQgaW5wdXRzOiBzdHJpbmdbXTtcbn1cbiJdfQ==
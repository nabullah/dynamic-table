/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef } from '@angular/core';
import { BaseDirective2, StyleUtils, StyleBuilder, MediaMarshaller } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export interface GridAreasParent {
    inline: boolean;
}
export declare class GridAreasStyleBuiler extends StyleBuilder {
    buildStyles(input: string, parent: GridAreasParent): {
        display: string;
        'grid-template-areas': string;
    };
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridAreasStyleBuiler, never>;
}
export declare class GridAreasDirective extends BaseDirective2 {
    protected DIRECTIVE_KEY: string;
    get inline(): boolean;
    set inline(val: boolean);
    protected _inline: boolean;
    constructor(elRef: ElementRef, styleUtils: StyleUtils, styleBuilder: GridAreasStyleBuiler, marshal: MediaMarshaller);
    protected updateWithValue(value: string): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridAreasDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<GridAreasDirective, never, never, { "inline": "gdInline"; }, {}, never>;
}
/**
 * 'grid-template-areas' CSS Grid styling directive
 * Configures the names of elements within the grid
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-14
 */
export declare class DefaultGridAreasDirective extends GridAreasDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultGridAreasDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultGridAreasDirective, "  [gdAreas],  [gdAreas.xs], [gdAreas.sm], [gdAreas.md], [gdAreas.lg], [gdAreas.xl],  [gdAreas.lt-sm], [gdAreas.lt-md], [gdAreas.lt-lg], [gdAreas.lt-xl],  [gdAreas.gt-xs], [gdAreas.gt-sm], [gdAreas.gt-md], [gdAreas.gt-lg]", never, { "gdAreas": "gdAreas"; "gdAreas.xs": "gdAreas.xs"; "gdAreas.sm": "gdAreas.sm"; "gdAreas.md": "gdAreas.md"; "gdAreas.lg": "gdAreas.lg"; "gdAreas.xl": "gdAreas.xl"; "gdAreas.lt-sm": "gdAreas.lt-sm"; "gdAreas.lt-md": "gdAreas.lt-md"; "gdAreas.lt-lg": "gdAreas.lt-lg"; "gdAreas.lt-xl": "gdAreas.lt-xl"; "gdAreas.gt-xs": "gdAreas.gt-xs"; "gdAreas.gt-sm": "gdAreas.gt-sm"; "gdAreas.gt-md": "gdAreas.gt-md"; "gdAreas.gt-lg": "gdAreas.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXJlYXMuZC50cyIsInNvdXJjZXMiOlsiYXJlYXMuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBHb29nbGUgTExDIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9hbmd1bGFyLmlvL2xpY2Vuc2VcbiAqL1xuaW1wb3J0IHsgRWxlbWVudFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmFzZURpcmVjdGl2ZTIsIFN0eWxlVXRpbHMsIFN0eWxlQnVpbGRlciwgTWVkaWFNYXJzaGFsbGVyIH0gZnJvbSAnQGFuZ3VsYXIvZmxleC1sYXlvdXQvY29yZSc7XG5leHBvcnQgaW50ZXJmYWNlIEdyaWRBcmVhc1BhcmVudCB7XG4gICAgaW5saW5lOiBib29sZWFuO1xufVxuZXhwb3J0IGRlY2xhcmUgY2xhc3MgR3JpZEFyZWFzU3R5bGVCdWlsZXIgZXh0ZW5kcyBTdHlsZUJ1aWxkZXIge1xuICAgIGJ1aWxkU3R5bGVzKGlucHV0OiBzdHJpbmcsIHBhcmVudDogR3JpZEFyZWFzUGFyZW50KToge1xuICAgICAgICBkaXNwbGF5OiBzdHJpbmc7XG4gICAgICAgICdncmlkLXRlbXBsYXRlLWFyZWFzJzogc3RyaW5nO1xuICAgIH07XG59XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBHcmlkQXJlYXNEaXJlY3RpdmUgZXh0ZW5kcyBCYXNlRGlyZWN0aXZlMiB7XG4gICAgcHJvdGVjdGVkIERJUkVDVElWRV9LRVk6IHN0cmluZztcbiAgICBnZXQgaW5saW5lKCk6IGJvb2xlYW47XG4gICAgc2V0IGlubGluZSh2YWw6IGJvb2xlYW4pO1xuICAgIHByb3RlY3RlZCBfaW5saW5lOiBib29sZWFuO1xuICAgIGNvbnN0cnVjdG9yKGVsUmVmOiBFbGVtZW50UmVmLCBzdHlsZVV0aWxzOiBTdHlsZVV0aWxzLCBzdHlsZUJ1aWxkZXI6IEdyaWRBcmVhc1N0eWxlQnVpbGVyLCBtYXJzaGFsOiBNZWRpYU1hcnNoYWxsZXIpO1xuICAgIHByb3RlY3RlZCB1cGRhdGVXaXRoVmFsdWUodmFsdWU6IHN0cmluZyk6IHZvaWQ7XG59XG4vKipcbiAqICdncmlkLXRlbXBsYXRlLWFyZWFzJyBDU1MgR3JpZCBzdHlsaW5nIGRpcmVjdGl2ZVxuICogQ29uZmlndXJlcyB0aGUgbmFtZXMgb2YgZWxlbWVudHMgd2l0aGluIHRoZSBncmlkXG4gKiBAc2VlIGh0dHBzOi8vY3NzLXRyaWNrcy5jb20vc25pcHBldHMvY3NzL2NvbXBsZXRlLWd1aWRlLWdyaWQvI2FydGljbGUtaGVhZGVyLWlkLTE0XG4gKi9cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIERlZmF1bHRHcmlkQXJlYXNEaXJlY3RpdmUgZXh0ZW5kcyBHcmlkQXJlYXNEaXJlY3RpdmUge1xuICAgIHByb3RlY3RlZCBpbnB1dHM6IHN0cmluZ1tdO1xufVxuIl19
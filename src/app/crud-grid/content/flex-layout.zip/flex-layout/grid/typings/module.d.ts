/**
 * *****************************************************************
 * Define module for the CSS Grid API
 * *****************************************************************
 */
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './grid-align/grid-align';
import * as ɵngcc2 from './align-columns/align-columns';
import * as ɵngcc3 from './align-rows/align-rows';
import * as ɵngcc4 from './area/area';
import * as ɵngcc5 from './areas/areas';
import * as ɵngcc6 from './auto/auto';
import * as ɵngcc7 from './column/column';
import * as ɵngcc8 from './columns/columns';
import * as ɵngcc9 from './gap/gap';
import * as ɵngcc10 from './row/row';
import * as ɵngcc11 from './rows/rows';
import * as ɵngcc12 from 'src/app/crud-grid/content/flex-layout/core';
export declare class GridModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<GridModule, [typeof ɵngcc1.DefaultGridAlignDirective, typeof ɵngcc2.DefaultGridAlignColumnsDirective, typeof ɵngcc3.DefaultGridAlignRowsDirective, typeof ɵngcc4.DefaultGridAreaDirective, typeof ɵngcc5.DefaultGridAreasDirective, typeof ɵngcc6.DefaultGridAutoDirective, typeof ɵngcc7.DefaultGridColumnDirective, typeof ɵngcc8.DefaultGridColumnsDirective, typeof ɵngcc9.DefaultGridGapDirective, typeof ɵngcc10.DefaultGridRowDirective, typeof ɵngcc11.DefaultGridRowsDirective], [typeof ɵngcc12.CoreModule], [typeof ɵngcc1.DefaultGridAlignDirective, typeof ɵngcc2.DefaultGridAlignColumnsDirective, typeof ɵngcc3.DefaultGridAlignRowsDirective, typeof ɵngcc4.DefaultGridAreaDirective, typeof ɵngcc5.DefaultGridAreasDirective, typeof ɵngcc6.DefaultGridAutoDirective, typeof ɵngcc7.DefaultGridColumnDirective, typeof ɵngcc8.DefaultGridColumnsDirective, typeof ɵngcc9.DefaultGridGapDirective, typeof ɵngcc10.DefaultGridRowDirective, typeof ɵngcc11.DefaultGridRowsDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<GridModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbIm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7O0FBQ0E7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogRGVmaW5lIG1vZHVsZSBmb3IgdGhlIENTUyBHcmlkIEFQSVxuICogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgR3JpZE1vZHVsZSB7XG59XG4iXX0=
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef } from '@angular/core';
import { BaseDirective2, StyleUtils, MediaMarshaller, StyleBuilder, StyleDefinition } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export declare class GridAreaStyleBuilder extends StyleBuilder {
    buildStyles(input: string): {
        'grid-area': string;
    };
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridAreaStyleBuilder, never>;
}
export declare class GridAreaDirective extends BaseDirective2 {
    protected DIRECTIVE_KEY: string;
    constructor(elRef: ElementRef, styleUtils: StyleUtils, styleBuilder: GridAreaStyleBuilder, marshal: MediaMarshaller);
    protected styleCache: Map<string, StyleDefinition>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridAreaDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<GridAreaDirective, never, never, {}, {}, never>;
}
/**
 * 'grid-area' CSS Grid styling directive
 * Configures the name or position of an element within the grid
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-27
 */
export declare class DefaultGridAreaDirective extends GridAreaDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultGridAreaDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultGridAreaDirective, "  [gdArea],  [gdArea.xs], [gdArea.sm], [gdArea.md], [gdArea.lg], [gdArea.xl],  [gdArea.lt-sm], [gdArea.lt-md], [gdArea.lt-lg], [gdArea.lt-xl],  [gdArea.gt-xs], [gdArea.gt-sm], [gdArea.gt-md], [gdArea.gt-lg]", never, { "gdArea": "gdArea"; "gdArea.xs": "gdArea.xs"; "gdArea.sm": "gdArea.sm"; "gdArea.md": "gdArea.md"; "gdArea.lg": "gdArea.lg"; "gdArea.xl": "gdArea.xl"; "gdArea.lt-sm": "gdArea.lt-sm"; "gdArea.lt-md": "gdArea.lt-md"; "gdArea.lt-lg": "gdArea.lt-lg"; "gdArea.lt-xl": "gdArea.lt-xl"; "gdArea.gt-xs": "gdArea.gt-xs"; "gdArea.gt-sm": "gdArea.gt-sm"; "gdArea.gt-md": "gdArea.gt-md"; "gdArea.gt-lg": "gdArea.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXJlYS5kLnRzIiwic291cmNlcyI6WyJhcmVhLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEdvb2dsZSBMTEMgQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2FuZ3VsYXIuaW8vbGljZW5zZVxuICovXG5pbXBvcnQgeyBFbGVtZW50UmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBCYXNlRGlyZWN0aXZlMiwgU3R5bGVVdGlscywgTWVkaWFNYXJzaGFsbGVyLCBTdHlsZUJ1aWxkZXIsIFN0eWxlRGVmaW5pdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2ZsZXgtbGF5b3V0L2NvcmUnO1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgR3JpZEFyZWFTdHlsZUJ1aWxkZXIgZXh0ZW5kcyBTdHlsZUJ1aWxkZXIge1xuICAgIGJ1aWxkU3R5bGVzKGlucHV0OiBzdHJpbmcpOiB7XG4gICAgICAgICdncmlkLWFyZWEnOiBzdHJpbmc7XG4gICAgfTtcbn1cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIEdyaWRBcmVhRGlyZWN0aXZlIGV4dGVuZHMgQmFzZURpcmVjdGl2ZTIge1xuICAgIHByb3RlY3RlZCBESVJFQ1RJVkVfS0VZOiBzdHJpbmc7XG4gICAgY29uc3RydWN0b3IoZWxSZWY6IEVsZW1lbnRSZWYsIHN0eWxlVXRpbHM6IFN0eWxlVXRpbHMsIHN0eWxlQnVpbGRlcjogR3JpZEFyZWFTdHlsZUJ1aWxkZXIsIG1hcnNoYWw6IE1lZGlhTWFyc2hhbGxlcik7XG4gICAgcHJvdGVjdGVkIHN0eWxlQ2FjaGU6IE1hcDxzdHJpbmcsIFN0eWxlRGVmaW5pdGlvbj47XG59XG4vKipcbiAqICdncmlkLWFyZWEnIENTUyBHcmlkIHN0eWxpbmcgZGlyZWN0aXZlXG4gKiBDb25maWd1cmVzIHRoZSBuYW1lIG9yIHBvc2l0aW9uIG9mIGFuIGVsZW1lbnQgd2l0aGluIHRoZSBncmlkXG4gKiBAc2VlIGh0dHBzOi8vY3NzLXRyaWNrcy5jb20vc25pcHBldHMvY3NzL2NvbXBsZXRlLWd1aWRlLWdyaWQvI2FydGljbGUtaGVhZGVyLWlkLTI3XG4gKi9cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIERlZmF1bHRHcmlkQXJlYURpcmVjdGl2ZSBleHRlbmRzIEdyaWRBcmVhRGlyZWN0aXZlIHtcbiAgICBwcm90ZWN0ZWQgaW5wdXRzOiBzdHJpbmdbXTtcbn1cbiJdfQ==
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef } from '@angular/core';
import { MediaMarshaller, BaseDirective2, StyleBuilder, StyleUtils } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export interface GridColumnsParent {
    inline: boolean;
}
export declare class GridColumnsStyleBuilder extends StyleBuilder {
    buildStyles(input: string, parent: GridColumnsParent): {
        display: string;
        'grid-auto-columns': string;
        'grid-template-columns': string;
    };
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridColumnsStyleBuilder, never>;
}
export declare class GridColumnsDirective extends BaseDirective2 {
    protected DIRECTIVE_KEY: string;
    get inline(): boolean;
    set inline(val: boolean);
    protected _inline: boolean;
    constructor(elementRef: ElementRef, styleBuilder: GridColumnsStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller);
    protected updateWithValue(value: string): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridColumnsDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<GridColumnsDirective, never, never, { "inline": "gdInline"; }, {}, never>;
}
/**
 * 'grid-template-columns' CSS Grid styling directive
 * Configures the sizing for the columns in the grid
 * Syntax: <column value> [auto]
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-13
 */
export declare class DefaultGridColumnsDirective extends GridColumnsDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultGridColumnsDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultGridColumnsDirective, "  [gdColumns],  [gdColumns.xs], [gdColumns.sm], [gdColumns.md], [gdColumns.lg], [gdColumns.xl],  [gdColumns.lt-sm], [gdColumns.lt-md], [gdColumns.lt-lg], [gdColumns.lt-xl],  [gdColumns.gt-xs], [gdColumns.gt-sm], [gdColumns.gt-md], [gdColumns.gt-lg]", never, { "gdColumns": "gdColumns"; "gdColumns.xs": "gdColumns.xs"; "gdColumns.sm": "gdColumns.sm"; "gdColumns.md": "gdColumns.md"; "gdColumns.lg": "gdColumns.lg"; "gdColumns.xl": "gdColumns.xl"; "gdColumns.lt-sm": "gdColumns.lt-sm"; "gdColumns.lt-md": "gdColumns.lt-md"; "gdColumns.lt-lg": "gdColumns.lt-lg"; "gdColumns.lt-xl": "gdColumns.lt-xl"; "gdColumns.gt-xs": "gdColumns.gt-xs"; "gdColumns.gt-sm": "gdColumns.gt-sm"; "gdColumns.gt-md": "gdColumns.gt-md"; "gdColumns.gt-lg": "gdColumns.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29sdW1ucy5kLnRzIiwic291cmNlcyI6WyJjb2x1bW5zLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEdvb2dsZSBMTEMgQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2FuZ3VsYXIuaW8vbGljZW5zZVxuICovXG5pbXBvcnQgeyBFbGVtZW50UmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBNZWRpYU1hcnNoYWxsZXIsIEJhc2VEaXJlY3RpdmUyLCBTdHlsZUJ1aWxkZXIsIFN0eWxlVXRpbHMgfSBmcm9tICdAYW5ndWxhci9mbGV4LWxheW91dC9jb3JlJztcbmV4cG9ydCBpbnRlcmZhY2UgR3JpZENvbHVtbnNQYXJlbnQge1xuICAgIGlubGluZTogYm9vbGVhbjtcbn1cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIEdyaWRDb2x1bW5zU3R5bGVCdWlsZGVyIGV4dGVuZHMgU3R5bGVCdWlsZGVyIHtcbiAgICBidWlsZFN0eWxlcyhpbnB1dDogc3RyaW5nLCBwYXJlbnQ6IEdyaWRDb2x1bW5zUGFyZW50KToge1xuICAgICAgICBkaXNwbGF5OiBzdHJpbmc7XG4gICAgICAgICdncmlkLWF1dG8tY29sdW1ucyc6IHN0cmluZztcbiAgICAgICAgJ2dyaWQtdGVtcGxhdGUtY29sdW1ucyc6IHN0cmluZztcbiAgICB9O1xufVxuZXhwb3J0IGRlY2xhcmUgY2xhc3MgR3JpZENvbHVtbnNEaXJlY3RpdmUgZXh0ZW5kcyBCYXNlRGlyZWN0aXZlMiB7XG4gICAgcHJvdGVjdGVkIERJUkVDVElWRV9LRVk6IHN0cmluZztcbiAgICBnZXQgaW5saW5lKCk6IGJvb2xlYW47XG4gICAgc2V0IGlubGluZSh2YWw6IGJvb2xlYW4pO1xuICAgIHByb3RlY3RlZCBfaW5saW5lOiBib29sZWFuO1xuICAgIGNvbnN0cnVjdG9yKGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsIHN0eWxlQnVpbGRlcjogR3JpZENvbHVtbnNTdHlsZUJ1aWxkZXIsIHN0eWxlcjogU3R5bGVVdGlscywgbWFyc2hhbDogTWVkaWFNYXJzaGFsbGVyKTtcbiAgICBwcm90ZWN0ZWQgdXBkYXRlV2l0aFZhbHVlKHZhbHVlOiBzdHJpbmcpOiB2b2lkO1xufVxuLyoqXG4gKiAnZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zJyBDU1MgR3JpZCBzdHlsaW5nIGRpcmVjdGl2ZVxuICogQ29uZmlndXJlcyB0aGUgc2l6aW5nIGZvciB0aGUgY29sdW1ucyBpbiB0aGUgZ3JpZFxuICogU3ludGF4OiA8Y29sdW1uIHZhbHVlPiBbYXV0b11cbiAqIEBzZWUgaHR0cHM6Ly9jc3MtdHJpY2tzLmNvbS9zbmlwcGV0cy9jc3MvY29tcGxldGUtZ3VpZGUtZ3JpZC8jYXJ0aWNsZS1oZWFkZXItaWQtMTNcbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgRGVmYXVsdEdyaWRDb2x1bW5zRGlyZWN0aXZlIGV4dGVuZHMgR3JpZENvbHVtbnNEaXJlY3RpdmUge1xuICAgIHByb3RlY3RlZCBpbnB1dHM6IHN0cmluZ1tdO1xufVxuIl19
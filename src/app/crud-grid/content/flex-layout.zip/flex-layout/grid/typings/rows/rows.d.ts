/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef } from '@angular/core';
import { MediaMarshaller, BaseDirective2, StyleBuilder, StyleUtils } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export interface GridRowsParent {
    inline: boolean;
}
export declare class GridRowsStyleBuilder extends StyleBuilder {
    buildStyles(input: string, parent: GridRowsParent): {
        display: string;
        'grid-auto-rows': string;
        'grid-template-rows': string;
    };
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridRowsStyleBuilder, never>;
}
export declare class GridRowsDirective extends BaseDirective2 {
    protected DIRECTIVE_KEY: string;
    get inline(): boolean;
    set inline(val: boolean);
    protected _inline: boolean;
    constructor(elementRef: ElementRef, styleBuilder: GridRowsStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller);
    protected updateWithValue(value: string): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridRowsDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<GridRowsDirective, never, never, { "inline": "gdInline"; }, {}, never>;
}
/**
 * 'grid-template-rows' CSS Grid styling directive
 * Configures the sizing for the rows in the grid
 * Syntax: <column value> [auto]
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-13
 */
export declare class DefaultGridRowsDirective extends GridRowsDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultGridRowsDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultGridRowsDirective, "  [gdRows],  [gdRows.xs], [gdRows.sm], [gdRows.md], [gdRows.lg], [gdRows.xl],  [gdRows.lt-sm], [gdRows.lt-md], [gdRows.lt-lg], [gdRows.lt-xl],  [gdRows.gt-xs], [gdRows.gt-sm], [gdRows.gt-md], [gdRows.gt-lg]", never, { "gdRows": "gdRows"; "gdRows.xs": "gdRows.xs"; "gdRows.sm": "gdRows.sm"; "gdRows.md": "gdRows.md"; "gdRows.lg": "gdRows.lg"; "gdRows.xl": "gdRows.xl"; "gdRows.lt-sm": "gdRows.lt-sm"; "gdRows.lt-md": "gdRows.lt-md"; "gdRows.lt-lg": "gdRows.lt-lg"; "gdRows.lt-xl": "gdRows.lt-xl"; "gdRows.gt-xs": "gdRows.gt-xs"; "gdRows.gt-sm": "gdRows.gt-sm"; "gdRows.gt-md": "gdRows.gt-md"; "gdRows.gt-lg": "gdRows.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm93cy5kLnRzIiwic291cmNlcyI6WyJyb3dzLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEdvb2dsZSBMTEMgQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2FuZ3VsYXIuaW8vbGljZW5zZVxuICovXG5pbXBvcnQgeyBFbGVtZW50UmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBNZWRpYU1hcnNoYWxsZXIsIEJhc2VEaXJlY3RpdmUyLCBTdHlsZUJ1aWxkZXIsIFN0eWxlVXRpbHMgfSBmcm9tICdAYW5ndWxhci9mbGV4LWxheW91dC9jb3JlJztcbmV4cG9ydCBpbnRlcmZhY2UgR3JpZFJvd3NQYXJlbnQge1xuICAgIGlubGluZTogYm9vbGVhbjtcbn1cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIEdyaWRSb3dzU3R5bGVCdWlsZGVyIGV4dGVuZHMgU3R5bGVCdWlsZGVyIHtcbiAgICBidWlsZFN0eWxlcyhpbnB1dDogc3RyaW5nLCBwYXJlbnQ6IEdyaWRSb3dzUGFyZW50KToge1xuICAgICAgICBkaXNwbGF5OiBzdHJpbmc7XG4gICAgICAgICdncmlkLWF1dG8tcm93cyc6IHN0cmluZztcbiAgICAgICAgJ2dyaWQtdGVtcGxhdGUtcm93cyc6IHN0cmluZztcbiAgICB9O1xufVxuZXhwb3J0IGRlY2xhcmUgY2xhc3MgR3JpZFJvd3NEaXJlY3RpdmUgZXh0ZW5kcyBCYXNlRGlyZWN0aXZlMiB7XG4gICAgcHJvdGVjdGVkIERJUkVDVElWRV9LRVk6IHN0cmluZztcbiAgICBnZXQgaW5saW5lKCk6IGJvb2xlYW47XG4gICAgc2V0IGlubGluZSh2YWw6IGJvb2xlYW4pO1xuICAgIHByb3RlY3RlZCBfaW5saW5lOiBib29sZWFuO1xuICAgIGNvbnN0cnVjdG9yKGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsIHN0eWxlQnVpbGRlcjogR3JpZFJvd3NTdHlsZUJ1aWxkZXIsIHN0eWxlcjogU3R5bGVVdGlscywgbWFyc2hhbDogTWVkaWFNYXJzaGFsbGVyKTtcbiAgICBwcm90ZWN0ZWQgdXBkYXRlV2l0aFZhbHVlKHZhbHVlOiBzdHJpbmcpOiB2b2lkO1xufVxuLyoqXG4gKiAnZ3JpZC10ZW1wbGF0ZS1yb3dzJyBDU1MgR3JpZCBzdHlsaW5nIGRpcmVjdGl2ZVxuICogQ29uZmlndXJlcyB0aGUgc2l6aW5nIGZvciB0aGUgcm93cyBpbiB0aGUgZ3JpZFxuICogU3ludGF4OiA8Y29sdW1uIHZhbHVlPiBbYXV0b11cbiAqIEBzZWUgaHR0cHM6Ly9jc3MtdHJpY2tzLmNvbS9zbmlwcGV0cy9jc3MvY29tcGxldGUtZ3VpZGUtZ3JpZC8jYXJ0aWNsZS1oZWFkZXItaWQtMTNcbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgRGVmYXVsdEdyaWRSb3dzRGlyZWN0aXZlIGV4dGVuZHMgR3JpZFJvd3NEaXJlY3RpdmUge1xuICAgIHByb3RlY3RlZCBpbnB1dHM6IHN0cmluZ1tdO1xufVxuIl19
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef } from '@angular/core';
import { BaseDirective2, StyleUtils, MediaMarshaller, StyleBuilder, StyleDefinition } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export declare class GridColumnStyleBuilder extends StyleBuilder {
    buildStyles(input: string): {
        'grid-column': string;
    };
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridColumnStyleBuilder, never>;
}
export declare class GridColumnDirective extends BaseDirective2 {
    protected DIRECTIVE_KEY: string;
    constructor(elementRef: ElementRef, styleBuilder: GridColumnStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller);
    protected styleCache: Map<string, StyleDefinition>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridColumnDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<GridColumnDirective, never, never, {}, {}, never>;
}
/**
 * 'grid-column' CSS Grid styling directive
 * Configures the name or position of an element within the grid
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-26
 */
export declare class DefaultGridColumnDirective extends GridColumnDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultGridColumnDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultGridColumnDirective, "  [gdColumn],  [gdColumn.xs], [gdColumn.sm], [gdColumn.md], [gdColumn.lg], [gdColumn.xl],  [gdColumn.lt-sm], [gdColumn.lt-md], [gdColumn.lt-lg], [gdColumn.lt-xl],  [gdColumn.gt-xs], [gdColumn.gt-sm], [gdColumn.gt-md], [gdColumn.gt-lg]", never, { "gdColumn": "gdColumn"; "gdColumn.xs": "gdColumn.xs"; "gdColumn.sm": "gdColumn.sm"; "gdColumn.md": "gdColumn.md"; "gdColumn.lg": "gdColumn.lg"; "gdColumn.xl": "gdColumn.xl"; "gdColumn.lt-sm": "gdColumn.lt-sm"; "gdColumn.lt-md": "gdColumn.lt-md"; "gdColumn.lt-lg": "gdColumn.lt-lg"; "gdColumn.lt-xl": "gdColumn.lt-xl"; "gdColumn.gt-xs": "gdColumn.gt-xs"; "gdColumn.gt-sm": "gdColumn.gt-sm"; "gdColumn.gt-md": "gdColumn.gt-md"; "gdColumn.gt-lg": "gdColumn.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29sdW1uLmQudHMiLCJzb3VyY2VzIjpbImNvbHVtbi5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBHb29nbGUgTExDIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9hbmd1bGFyLmlvL2xpY2Vuc2VcbiAqL1xuaW1wb3J0IHsgRWxlbWVudFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmFzZURpcmVjdGl2ZTIsIFN0eWxlVXRpbHMsIE1lZGlhTWFyc2hhbGxlciwgU3R5bGVCdWlsZGVyLCBTdHlsZURlZmluaXRpb24gfSBmcm9tICdAYW5ndWxhci9mbGV4LWxheW91dC9jb3JlJztcbmV4cG9ydCBkZWNsYXJlIGNsYXNzIEdyaWRDb2x1bW5TdHlsZUJ1aWxkZXIgZXh0ZW5kcyBTdHlsZUJ1aWxkZXIge1xuICAgIGJ1aWxkU3R5bGVzKGlucHV0OiBzdHJpbmcpOiB7XG4gICAgICAgICdncmlkLWNvbHVtbic6IHN0cmluZztcbiAgICB9O1xufVxuZXhwb3J0IGRlY2xhcmUgY2xhc3MgR3JpZENvbHVtbkRpcmVjdGl2ZSBleHRlbmRzIEJhc2VEaXJlY3RpdmUyIHtcbiAgICBwcm90ZWN0ZWQgRElSRUNUSVZFX0tFWTogc3RyaW5nO1xuICAgIGNvbnN0cnVjdG9yKGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsIHN0eWxlQnVpbGRlcjogR3JpZENvbHVtblN0eWxlQnVpbGRlciwgc3R5bGVyOiBTdHlsZVV0aWxzLCBtYXJzaGFsOiBNZWRpYU1hcnNoYWxsZXIpO1xuICAgIHByb3RlY3RlZCBzdHlsZUNhY2hlOiBNYXA8c3RyaW5nLCBTdHlsZURlZmluaXRpb24+O1xufVxuLyoqXG4gKiAnZ3JpZC1jb2x1bW4nIENTUyBHcmlkIHN0eWxpbmcgZGlyZWN0aXZlXG4gKiBDb25maWd1cmVzIHRoZSBuYW1lIG9yIHBvc2l0aW9uIG9mIGFuIGVsZW1lbnQgd2l0aGluIHRoZSBncmlkXG4gKiBAc2VlIGh0dHBzOi8vY3NzLXRyaWNrcy5jb20vc25pcHBldHMvY3NzL2NvbXBsZXRlLWd1aWRlLWdyaWQvI2FydGljbGUtaGVhZGVyLWlkLTI2XG4gKi9cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIERlZmF1bHRHcmlkQ29sdW1uRGlyZWN0aXZlIGV4dGVuZHMgR3JpZENvbHVtbkRpcmVjdGl2ZSB7XG4gICAgcHJvdGVjdGVkIGlucHV0czogc3RyaW5nW107XG59XG4iXX0=
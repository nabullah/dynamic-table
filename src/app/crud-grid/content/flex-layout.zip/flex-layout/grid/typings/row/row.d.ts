/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef } from '@angular/core';
import { BaseDirective2, StyleUtils, MediaMarshaller, StyleBuilder, StyleDefinition } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export declare class GridRowStyleBuilder extends StyleBuilder {
    buildStyles(input: string): {
        'grid-row': string;
    };
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridRowStyleBuilder, never>;
}
export declare class GridRowDirective extends BaseDirective2 {
    protected DIRECTIVE_KEY: string;
    constructor(elementRef: ElementRef, styleBuilder: GridRowStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller);
    protected styleCache: Map<string, StyleDefinition>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<GridRowDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<GridRowDirective, never, never, {}, {}, never>;
}
/**
 * 'grid-row' CSS Grid styling directive
 * Configures the name or position of an element within the grid
 * @see https://css-tricks.com/snippets/css/complete-guide-grid/#article-header-id-26
 */
export declare class DefaultGridRowDirective extends GridRowDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultGridRowDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultGridRowDirective, "  [gdRow],  [gdRow.xs], [gdRow.sm], [gdRow.md], [gdRow.lg], [gdRow.xl],  [gdRow.lt-sm], [gdRow.lt-md], [gdRow.lt-lg], [gdRow.lt-xl],  [gdRow.gt-xs], [gdRow.gt-sm], [gdRow.gt-md], [gdRow.gt-lg]", never, { "gdRow": "gdRow"; "gdRow.xs": "gdRow.xs"; "gdRow.sm": "gdRow.sm"; "gdRow.md": "gdRow.md"; "gdRow.lg": "gdRow.lg"; "gdRow.xl": "gdRow.xl"; "gdRow.lt-sm": "gdRow.lt-sm"; "gdRow.lt-md": "gdRow.lt-md"; "gdRow.lt-lg": "gdRow.lt-lg"; "gdRow.lt-xl": "gdRow.lt-xl"; "gdRow.gt-xs": "gdRow.gt-xs"; "gdRow.gt-sm": "gdRow.gt-sm"; "gdRow.gt-md": "gdRow.gt-md"; "gdRow.gt-lg": "gdRow.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm93LmQudHMiLCJzb3VyY2VzIjpbInJvdy5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBHb29nbGUgTExDIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9hbmd1bGFyLmlvL2xpY2Vuc2VcbiAqL1xuaW1wb3J0IHsgRWxlbWVudFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmFzZURpcmVjdGl2ZTIsIFN0eWxlVXRpbHMsIE1lZGlhTWFyc2hhbGxlciwgU3R5bGVCdWlsZGVyLCBTdHlsZURlZmluaXRpb24gfSBmcm9tICdAYW5ndWxhci9mbGV4LWxheW91dC9jb3JlJztcbmV4cG9ydCBkZWNsYXJlIGNsYXNzIEdyaWRSb3dTdHlsZUJ1aWxkZXIgZXh0ZW5kcyBTdHlsZUJ1aWxkZXIge1xuICAgIGJ1aWxkU3R5bGVzKGlucHV0OiBzdHJpbmcpOiB7XG4gICAgICAgICdncmlkLXJvdyc6IHN0cmluZztcbiAgICB9O1xufVxuZXhwb3J0IGRlY2xhcmUgY2xhc3MgR3JpZFJvd0RpcmVjdGl2ZSBleHRlbmRzIEJhc2VEaXJlY3RpdmUyIHtcbiAgICBwcm90ZWN0ZWQgRElSRUNUSVZFX0tFWTogc3RyaW5nO1xuICAgIGNvbnN0cnVjdG9yKGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsIHN0eWxlQnVpbGRlcjogR3JpZFJvd1N0eWxlQnVpbGRlciwgc3R5bGVyOiBTdHlsZVV0aWxzLCBtYXJzaGFsOiBNZWRpYU1hcnNoYWxsZXIpO1xuICAgIHByb3RlY3RlZCBzdHlsZUNhY2hlOiBNYXA8c3RyaW5nLCBTdHlsZURlZmluaXRpb24+O1xufVxuLyoqXG4gKiAnZ3JpZC1yb3cnIENTUyBHcmlkIHN0eWxpbmcgZGlyZWN0aXZlXG4gKiBDb25maWd1cmVzIHRoZSBuYW1lIG9yIHBvc2l0aW9uIG9mIGFuIGVsZW1lbnQgd2l0aGluIHRoZSBncmlkXG4gKiBAc2VlIGh0dHBzOi8vY3NzLXRyaWNrcy5jb20vc25pcHBldHMvY3NzL2NvbXBsZXRlLWd1aWRlLWdyaWQvI2FydGljbGUtaGVhZGVyLWlkLTI2XG4gKi9cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIERlZmF1bHRHcmlkUm93RGlyZWN0aXZlIGV4dGVuZHMgR3JpZFJvd0RpcmVjdGl2ZSB7XG4gICAgcHJvdGVjdGVkIGlucHV0czogc3RyaW5nW107XG59XG4iXX0=
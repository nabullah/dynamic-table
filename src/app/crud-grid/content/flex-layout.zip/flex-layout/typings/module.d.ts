/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ModuleWithProviders } from '@angular/core';
import { LayoutConfigOptions, BreakPoint } from 'src/app/crud-grid/content/flex-layout/core';
/**
 * FlexLayoutModule -- the main import for all utilities in the Angular Layout library
 * * Will automatically provide Flex, Grid, and Extended modules for use in the application
 * * Can be configured using the static withConfig method, options viewable on the Wiki's
 *   Configuration page
 */
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from 'src/app/crud-grid/content/flex-layout/flex';
import * as ɵngcc2 from 'src/app/crud-grid/content/flex-layout/extended';
import * as ɵngcc3 from 'src/app/crud-grid/content/flex-layout/grid';
export declare class FlexLayoutModule {
    /**
     * Initialize the FlexLayoutModule with a set of config options,
     * which sets the corresponding tokens accordingly
     */
    static withConfig(configOptions: LayoutConfigOptions, breakpoints?: BreakPoint | BreakPoint[]): ModuleWithProviders<FlexLayoutModule>;
    constructor(serverModuleLoaded: boolean, platformId: Object);
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<FlexLayoutModule, never, [typeof ɵngcc1.FlexModule, typeof ɵngcc2.ExtendedModule, typeof ɵngcc3.GridModule], [typeof ɵngcc1.FlexModule, typeof ɵngcc2.ExtendedModule, typeof ɵngcc3.GridModule]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<FlexLayoutModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbIm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgR29vZ2xlIExMQyBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vYW5ndWxhci5pby9saWNlbnNlXG4gKi9cbmltcG9ydCB7IE1vZHVsZVdpdGhQcm92aWRlcnMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IExheW91dENvbmZpZ09wdGlvbnMsIEJyZWFrUG9pbnQgfSBmcm9tICdAYW5ndWxhci9mbGV4LWxheW91dC9jb3JlJztcbi8qKlxuICogRmxleExheW91dE1vZHVsZSAtLSB0aGUgbWFpbiBpbXBvcnQgZm9yIGFsbCB1dGlsaXRpZXMgaW4gdGhlIEFuZ3VsYXIgTGF5b3V0IGxpYnJhcnlcbiAqICogV2lsbCBhdXRvbWF0aWNhbGx5IHByb3ZpZGUgRmxleCwgR3JpZCwgYW5kIEV4dGVuZGVkIG1vZHVsZXMgZm9yIHVzZSBpbiB0aGUgYXBwbGljYXRpb25cbiAqICogQ2FuIGJlIGNvbmZpZ3VyZWQgdXNpbmcgdGhlIHN0YXRpYyB3aXRoQ29uZmlnIG1ldGhvZCwgb3B0aW9ucyB2aWV3YWJsZSBvbiB0aGUgV2lraSdzXG4gKiAgIENvbmZpZ3VyYXRpb24gcGFnZVxuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBGbGV4TGF5b3V0TW9kdWxlIHtcbiAgICAvKipcbiAgICAgKiBJbml0aWFsaXplIHRoZSBGbGV4TGF5b3V0TW9kdWxlIHdpdGggYSBzZXQgb2YgY29uZmlnIG9wdGlvbnMsXG4gICAgICogd2hpY2ggc2V0cyB0aGUgY29ycmVzcG9uZGluZyB0b2tlbnMgYWNjb3JkaW5nbHlcbiAgICAgKi9cbiAgICBzdGF0aWMgd2l0aENvbmZpZyhjb25maWdPcHRpb25zOiBMYXlvdXRDb25maWdPcHRpb25zLCBicmVha3BvaW50cz86IEJyZWFrUG9pbnQgfCBCcmVha1BvaW50W10pOiBNb2R1bGVXaXRoUHJvdmlkZXJzPEZsZXhMYXlvdXRNb2R1bGU+O1xuICAgIGNvbnN0cnVjdG9yKHNlcnZlck1vZHVsZUxvYWRlZDogYm9vbGVhbiwgcGxhdGZvcm1JZDogT2JqZWN0KTtcbn1cbiJdfQ==
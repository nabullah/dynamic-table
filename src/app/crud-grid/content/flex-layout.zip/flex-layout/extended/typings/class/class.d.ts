/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { DoCheck, ElementRef, IterableDiffers, KeyValueDiffers, Renderer2 } from '@angular/core';
import { NgClass } from '@angular/common';
import { BaseDirective2, StyleUtils, MediaMarshaller } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export declare class ClassDirective extends BaseDirective2 implements DoCheck {
    protected readonly ngClassInstance: NgClass;
    protected DIRECTIVE_KEY: string;
    /**
     * Capture class assignments so we cache the default classes
     * which are merged with activated styles and used as fallbacks.
     */
    set klass(val: string);
    constructor(elementRef: ElementRef, styler: StyleUtils, marshal: MediaMarshaller, iterableDiffers: IterableDiffers, keyValueDiffers: KeyValueDiffers, renderer2: Renderer2, ngClassInstance: NgClass);
    protected updateWithValue(value: any): void;
    /**
     * For ChangeDetectionStrategy.onPush and ngOnChanges() updates
     */
    ngDoCheck(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ClassDirective, [null, null, null, null, null, null, { optional: true; self: true; }]>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<ClassDirective, never, never, { "klass": "class"; }, {}, never>;
}
/**
 * Directive to add responsive support for ngClass.
 * This maintains the core functionality of 'ngClass' and adds responsive API
 * Note: this class is a no-op when rendered on the server
 */
export declare class DefaultClassDirective extends ClassDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultClassDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultClassDirective, "  [ngClass], [ngClass.xs], [ngClass.sm], [ngClass.md], [ngClass.lg], [ngClass.xl],  [ngClass.lt-sm], [ngClass.lt-md], [ngClass.lt-lg], [ngClass.lt-xl],  [ngClass.gt-xs], [ngClass.gt-sm], [ngClass.gt-md], [ngClass.gt-lg]", never, { "ngClass": "ngClass"; "ngClass.xs": "ngClass.xs"; "ngClass.sm": "ngClass.sm"; "ngClass.md": "ngClass.md"; "ngClass.lg": "ngClass.lg"; "ngClass.xl": "ngClass.xl"; "ngClass.lt-sm": "ngClass.lt-sm"; "ngClass.lt-md": "ngClass.lt-md"; "ngClass.lt-lg": "ngClass.lt-lg"; "ngClass.lt-xl": "ngClass.lt-xl"; "ngClass.gt-xs": "ngClass.gt-xs"; "ngClass.gt-sm": "ngClass.gt-sm"; "ngClass.gt-md": "ngClass.gt-md"; "ngClass.gt-lg": "ngClass.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xhc3MuZC50cyIsInNvdXJjZXMiOlsiY2xhc3MuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBHb29nbGUgTExDIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9hbmd1bGFyLmlvL2xpY2Vuc2VcbiAqL1xuaW1wb3J0IHsgRG9DaGVjaywgRWxlbWVudFJlZiwgSXRlcmFibGVEaWZmZXJzLCBLZXlWYWx1ZURpZmZlcnMsIFJlbmRlcmVyMiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTmdDbGFzcyB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBCYXNlRGlyZWN0aXZlMiwgU3R5bGVVdGlscywgTWVkaWFNYXJzaGFsbGVyIH0gZnJvbSAnQGFuZ3VsYXIvZmxleC1sYXlvdXQvY29yZSc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBDbGFzc0RpcmVjdGl2ZSBleHRlbmRzIEJhc2VEaXJlY3RpdmUyIGltcGxlbWVudHMgRG9DaGVjayB7XG4gICAgcHJvdGVjdGVkIHJlYWRvbmx5IG5nQ2xhc3NJbnN0YW5jZTogTmdDbGFzcztcbiAgICBwcm90ZWN0ZWQgRElSRUNUSVZFX0tFWTogc3RyaW5nO1xuICAgIC8qKlxuICAgICAqIENhcHR1cmUgY2xhc3MgYXNzaWdubWVudHMgc28gd2UgY2FjaGUgdGhlIGRlZmF1bHQgY2xhc3Nlc1xuICAgICAqIHdoaWNoIGFyZSBtZXJnZWQgd2l0aCBhY3RpdmF0ZWQgc3R5bGVzIGFuZCB1c2VkIGFzIGZhbGxiYWNrcy5cbiAgICAgKi9cbiAgICBzZXQga2xhc3ModmFsOiBzdHJpbmcpO1xuICAgIGNvbnN0cnVjdG9yKGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsIHN0eWxlcjogU3R5bGVVdGlscywgbWFyc2hhbDogTWVkaWFNYXJzaGFsbGVyLCBpdGVyYWJsZURpZmZlcnM6IEl0ZXJhYmxlRGlmZmVycywga2V5VmFsdWVEaWZmZXJzOiBLZXlWYWx1ZURpZmZlcnMsIHJlbmRlcmVyMjogUmVuZGVyZXIyLCBuZ0NsYXNzSW5zdGFuY2U6IE5nQ2xhc3MpO1xuICAgIHByb3RlY3RlZCB1cGRhdGVXaXRoVmFsdWUodmFsdWU6IGFueSk6IHZvaWQ7XG4gICAgLyoqXG4gICAgICogRm9yIENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lm9uUHVzaCBhbmQgbmdPbkNoYW5nZXMoKSB1cGRhdGVzXG4gICAgICovXG4gICAgbmdEb0NoZWNrKCk6IHZvaWQ7XG59XG4vKipcbiAqIERpcmVjdGl2ZSB0byBhZGQgcmVzcG9uc2l2ZSBzdXBwb3J0IGZvciBuZ0NsYXNzLlxuICogVGhpcyBtYWludGFpbnMgdGhlIGNvcmUgZnVuY3Rpb25hbGl0eSBvZiAnbmdDbGFzcycgYW5kIGFkZHMgcmVzcG9uc2l2ZSBBUElcbiAqIE5vdGU6IHRoaXMgY2xhc3MgaXMgYSBuby1vcCB3aGVuIHJlbmRlcmVkIG9uIHRoZSBzZXJ2ZXJcbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgRGVmYXVsdENsYXNzRGlyZWN0aXZlIGV4dGVuZHMgQ2xhc3NEaXJlY3RpdmUge1xuICAgIHByb3RlY3RlZCBpbnB1dHM6IHN0cmluZ1tdO1xufVxuIl19
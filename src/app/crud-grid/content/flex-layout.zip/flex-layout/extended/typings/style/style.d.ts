/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { DoCheck, ElementRef, KeyValueDiffers, Renderer2 } from '@angular/core';
import { NgStyle } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';
import { BaseDirective2, StyleUtils, MediaMarshaller } from 'src/app/crud-grid/content/flex-layout/core';
import { NgStyleType, NgStyleMap } from './style-transforms';
import * as ɵngcc0 from '@angular/core';
export declare class StyleDirective extends BaseDirective2 implements DoCheck {
    protected sanitizer: DomSanitizer;
    private readonly ngStyleInstance;
    protected DIRECTIVE_KEY: string;
    protected fallbackStyles: NgStyleMap;
    protected isServer: boolean;
    constructor(elementRef: ElementRef, styler: StyleUtils, marshal: MediaMarshaller, sanitizer: DomSanitizer, differs: KeyValueDiffers, renderer2: Renderer2, ngStyleInstance: NgStyle, serverLoaded: boolean, platformId: Object);
    /** Add generated styles */
    protected updateWithValue(value: any): void;
    /** Remove generated styles */
    protected clearStyles(): void;
    /**
     * Convert raw strings to ngStyleMap; which is required by ngStyle
     * NOTE: Raw string key-value pairs MUST be delimited by `;`
     *       Comma-delimiters are not supported due to complexities of
     *       possible style values such as `rgba(x,x,x,x)` and others
     */
    protected buildStyleMap(styles: NgStyleType): NgStyleMap;
    /** For ChangeDetectionStrategy.onPush and ngOnChanges() updates */
    ngDoCheck(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<StyleDirective, [null, null, null, null, null, null, { optional: true; self: true; }, null, null]>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<StyleDirective, never, never, {}, {}, never>;
}
/**
 * Directive to add responsive support for ngStyle.
 *
 */
export declare class DefaultStyleDirective extends StyleDirective implements DoCheck {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultStyleDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultStyleDirective, "  [ngStyle],  [ngStyle.xs], [ngStyle.sm], [ngStyle.md], [ngStyle.lg], [ngStyle.xl],  [ngStyle.lt-sm], [ngStyle.lt-md], [ngStyle.lt-lg], [ngStyle.lt-xl],  [ngStyle.gt-xs], [ngStyle.gt-sm], [ngStyle.gt-md], [ngStyle.gt-lg]", never, { "ngStyle": "ngStyle"; "ngStyle.xs": "ngStyle.xs"; "ngStyle.sm": "ngStyle.sm"; "ngStyle.md": "ngStyle.md"; "ngStyle.lg": "ngStyle.lg"; "ngStyle.xl": "ngStyle.xl"; "ngStyle.lt-sm": "ngStyle.lt-sm"; "ngStyle.lt-md": "ngStyle.lt-md"; "ngStyle.lt-lg": "ngStyle.lt-lg"; "ngStyle.lt-xl": "ngStyle.lt-xl"; "ngStyle.gt-xs": "ngStyle.gt-xs"; "ngStyle.gt-sm": "ngStyle.gt-sm"; "ngStyle.gt-md": "ngStyle.gt-md"; "ngStyle.gt-lg": "ngStyle.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3R5bGUuZC50cyIsInNvdXJjZXMiOlsic3R5bGUuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEdvb2dsZSBMTEMgQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2FuZ3VsYXIuaW8vbGljZW5zZVxuICovXG5pbXBvcnQgeyBEb0NoZWNrLCBFbGVtZW50UmVmLCBLZXlWYWx1ZURpZmZlcnMsIFJlbmRlcmVyMiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTmdTdHlsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBEb21TYW5pdGl6ZXIgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcbmltcG9ydCB7IEJhc2VEaXJlY3RpdmUyLCBTdHlsZVV0aWxzLCBNZWRpYU1hcnNoYWxsZXIgfSBmcm9tICdAYW5ndWxhci9mbGV4LWxheW91dC9jb3JlJztcbmltcG9ydCB7IE5nU3R5bGVUeXBlLCBOZ1N0eWxlTWFwIH0gZnJvbSAnLi9zdHlsZS10cmFuc2Zvcm1zJztcbmV4cG9ydCBkZWNsYXJlIGNsYXNzIFN0eWxlRGlyZWN0aXZlIGV4dGVuZHMgQmFzZURpcmVjdGl2ZTIgaW1wbGVtZW50cyBEb0NoZWNrIHtcbiAgICBwcm90ZWN0ZWQgc2FuaXRpemVyOiBEb21TYW5pdGl6ZXI7XG4gICAgcHJpdmF0ZSByZWFkb25seSBuZ1N0eWxlSW5zdGFuY2U7XG4gICAgcHJvdGVjdGVkIERJUkVDVElWRV9LRVk6IHN0cmluZztcbiAgICBwcm90ZWN0ZWQgZmFsbGJhY2tTdHlsZXM6IE5nU3R5bGVNYXA7XG4gICAgcHJvdGVjdGVkIGlzU2VydmVyOiBib29sZWFuO1xuICAgIGNvbnN0cnVjdG9yKGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsIHN0eWxlcjogU3R5bGVVdGlscywgbWFyc2hhbDogTWVkaWFNYXJzaGFsbGVyLCBzYW5pdGl6ZXI6IERvbVNhbml0aXplciwgZGlmZmVyczogS2V5VmFsdWVEaWZmZXJzLCByZW5kZXJlcjI6IFJlbmRlcmVyMiwgbmdTdHlsZUluc3RhbmNlOiBOZ1N0eWxlLCBzZXJ2ZXJMb2FkZWQ6IGJvb2xlYW4sIHBsYXRmb3JtSWQ6IE9iamVjdCk7XG4gICAgLyoqIEFkZCBnZW5lcmF0ZWQgc3R5bGVzICovXG4gICAgcHJvdGVjdGVkIHVwZGF0ZVdpdGhWYWx1ZSh2YWx1ZTogYW55KTogdm9pZDtcbiAgICAvKiogUmVtb3ZlIGdlbmVyYXRlZCBzdHlsZXMgKi9cbiAgICBwcm90ZWN0ZWQgY2xlYXJTdHlsZXMoKTogdm9pZDtcbiAgICAvKipcbiAgICAgKiBDb252ZXJ0IHJhdyBzdHJpbmdzIHRvIG5nU3R5bGVNYXA7IHdoaWNoIGlzIHJlcXVpcmVkIGJ5IG5nU3R5bGVcbiAgICAgKiBOT1RFOiBSYXcgc3RyaW5nIGtleS12YWx1ZSBwYWlycyBNVVNUIGJlIGRlbGltaXRlZCBieSBgO2BcbiAgICAgKiAgICAgICBDb21tYS1kZWxpbWl0ZXJzIGFyZSBub3Qgc3VwcG9ydGVkIGR1ZSB0byBjb21wbGV4aXRpZXMgb2ZcbiAgICAgKiAgICAgICBwb3NzaWJsZSBzdHlsZSB2YWx1ZXMgc3VjaCBhcyBgcmdiYSh4LHgseCx4KWAgYW5kIG90aGVyc1xuICAgICAqL1xuICAgIHByb3RlY3RlZCBidWlsZFN0eWxlTWFwKHN0eWxlczogTmdTdHlsZVR5cGUpOiBOZ1N0eWxlTWFwO1xuICAgIC8qKiBGb3IgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kub25QdXNoIGFuZCBuZ09uQ2hhbmdlcygpIHVwZGF0ZXMgKi9cbiAgICBuZ0RvQ2hlY2soKTogdm9pZDtcbn1cbi8qKlxuICogRGlyZWN0aXZlIHRvIGFkZCByZXNwb25zaXZlIHN1cHBvcnQgZm9yIG5nU3R5bGUuXG4gKlxuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBEZWZhdWx0U3R5bGVEaXJlY3RpdmUgZXh0ZW5kcyBTdHlsZURpcmVjdGl2ZSBpbXBsZW1lbnRzIERvQ2hlY2sge1xuICAgIHByb3RlY3RlZCBpbnB1dHM6IHN0cmluZ1tdO1xufVxuIl19
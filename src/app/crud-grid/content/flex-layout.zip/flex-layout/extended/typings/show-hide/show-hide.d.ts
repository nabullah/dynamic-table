/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef, OnChanges, SimpleChanges, AfterViewInit } from '@angular/core';
import { BaseDirective2, LayoutConfigOptions, MediaMarshaller, StyleUtils, StyleBuilder } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export interface ShowHideParent {
    display: string;
    isServer: boolean;
}
export declare class ShowHideStyleBuilder extends StyleBuilder {
    buildStyles(show: string, parent: ShowHideParent): {
        display: string;
    };
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ShowHideStyleBuilder, never>;
}
export declare class ShowHideDirective extends BaseDirective2 implements AfterViewInit, OnChanges {
    protected layoutConfig: LayoutConfigOptions;
    protected platformId: Object;
    protected serverModuleLoaded: boolean;
    protected DIRECTIVE_KEY: string;
    /** Original DOM Element CSS display style */
    protected display: string;
    protected hasLayout: boolean;
    protected hasFlexChild: boolean;
    constructor(elementRef: ElementRef, styleBuilder: ShowHideStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller, layoutConfig: LayoutConfigOptions, platformId: Object, serverModuleLoaded: boolean);
    ngAfterViewInit(): void;
    /**
     * On changes to any @Input properties...
     * Default to use the non-responsive Input value ('fxShow')
     * Then conditionally override with the mq-activated Input's current value
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     *  Watch for these extra triggers to update fxShow, fxHide stylings
     */
    protected trackExtraTriggers(): void;
    /**
     * Override accessor to the current HTMLElement's `display` style
     * Note: Show/Hide will not change the display to 'flex' but will set it to 'block'
     * unless it was already explicitly specified inline or in a CSS stylesheet.
     */
    protected getDisplayStyle(): string;
    /** Validate the visibility value and then update the host's inline display style */
    protected updateWithValue(value?: boolean | string): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ShowHideDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<ShowHideDirective, never, never, {}, {}, never>;
}
/**
 * 'show' Layout API directive
 */
export declare class DefaultShowHideDirective extends ShowHideDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultShowHideDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultShowHideDirective, "  [fxShow], [fxShow.print],  [fxShow.xs], [fxShow.sm], [fxShow.md], [fxShow.lg], [fxShow.xl],  [fxShow.lt-sm], [fxShow.lt-md], [fxShow.lt-lg], [fxShow.lt-xl],  [fxShow.gt-xs], [fxShow.gt-sm], [fxShow.gt-md], [fxShow.gt-lg],  [fxHide], [fxHide.print],  [fxHide.xs], [fxHide.sm], [fxHide.md], [fxHide.lg], [fxHide.xl],  [fxHide.lt-sm], [fxHide.lt-md], [fxHide.lt-lg], [fxHide.lt-xl],  [fxHide.gt-xs], [fxHide.gt-sm], [fxHide.gt-md], [fxHide.gt-lg]", never, { "fxShow": "fxShow"; "fxShow.print": "fxShow.print"; "fxShow.xs": "fxShow.xs"; "fxShow.sm": "fxShow.sm"; "fxShow.md": "fxShow.md"; "fxShow.lg": "fxShow.lg"; "fxShow.xl": "fxShow.xl"; "fxShow.lt-sm": "fxShow.lt-sm"; "fxShow.lt-md": "fxShow.lt-md"; "fxShow.lt-lg": "fxShow.lt-lg"; "fxShow.lt-xl": "fxShow.lt-xl"; "fxShow.gt-xs": "fxShow.gt-xs"; "fxShow.gt-sm": "fxShow.gt-sm"; "fxShow.gt-md": "fxShow.gt-md"; "fxShow.gt-lg": "fxShow.gt-lg"; "fxHide": "fxHide"; "fxHide.print": "fxHide.print"; "fxHide.xs": "fxHide.xs"; "fxHide.sm": "fxHide.sm"; "fxHide.md": "fxHide.md"; "fxHide.lg": "fxHide.lg"; "fxHide.xl": "fxHide.xl"; "fxHide.lt-sm": "fxHide.lt-sm"; "fxHide.lt-md": "fxHide.lt-md"; "fxHide.lt-lg": "fxHide.lt-lg"; "fxHide.lt-xl": "fxHide.lt-xl"; "fxHide.gt-xs": "fxHide.gt-xs"; "fxHide.gt-sm": "fxHide.gt-sm"; "fxHide.gt-md": "fxHide.gt-md"; "fxHide.gt-lg": "fxHide.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2hvdy1oaWRlLmQudHMiLCJzb3VyY2VzIjpbInNob3ctaGlkZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBHb29nbGUgTExDIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9hbmd1bGFyLmlvL2xpY2Vuc2VcbiAqL1xuaW1wb3J0IHsgRWxlbWVudFJlZiwgT25DaGFuZ2VzLCBTaW1wbGVDaGFuZ2VzLCBBZnRlclZpZXdJbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBCYXNlRGlyZWN0aXZlMiwgTGF5b3V0Q29uZmlnT3B0aW9ucywgTWVkaWFNYXJzaGFsbGVyLCBTdHlsZVV0aWxzLCBTdHlsZUJ1aWxkZXIgfSBmcm9tICdAYW5ndWxhci9mbGV4LWxheW91dC9jb3JlJztcbmV4cG9ydCBpbnRlcmZhY2UgU2hvd0hpZGVQYXJlbnQge1xuICAgIGRpc3BsYXk6IHN0cmluZztcbiAgICBpc1NlcnZlcjogYm9vbGVhbjtcbn1cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIFNob3dIaWRlU3R5bGVCdWlsZGVyIGV4dGVuZHMgU3R5bGVCdWlsZGVyIHtcbiAgICBidWlsZFN0eWxlcyhzaG93OiBzdHJpbmcsIHBhcmVudDogU2hvd0hpZGVQYXJlbnQpOiB7XG4gICAgICAgIGRpc3BsYXk6IHN0cmluZztcbiAgICB9O1xufVxuZXhwb3J0IGRlY2xhcmUgY2xhc3MgU2hvd0hpZGVEaXJlY3RpdmUgZXh0ZW5kcyBCYXNlRGlyZWN0aXZlMiBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQsIE9uQ2hhbmdlcyB7XG4gICAgcHJvdGVjdGVkIGxheW91dENvbmZpZzogTGF5b3V0Q29uZmlnT3B0aW9ucztcbiAgICBwcm90ZWN0ZWQgcGxhdGZvcm1JZDogT2JqZWN0O1xuICAgIHByb3RlY3RlZCBzZXJ2ZXJNb2R1bGVMb2FkZWQ6IGJvb2xlYW47XG4gICAgcHJvdGVjdGVkIERJUkVDVElWRV9LRVk6IHN0cmluZztcbiAgICAvKiogT3JpZ2luYWwgRE9NIEVsZW1lbnQgQ1NTIGRpc3BsYXkgc3R5bGUgKi9cbiAgICBwcm90ZWN0ZWQgZGlzcGxheTogc3RyaW5nO1xuICAgIHByb3RlY3RlZCBoYXNMYXlvdXQ6IGJvb2xlYW47XG4gICAgcHJvdGVjdGVkIGhhc0ZsZXhDaGlsZDogYm9vbGVhbjtcbiAgICBjb25zdHJ1Y3RvcihlbGVtZW50UmVmOiBFbGVtZW50UmVmLCBzdHlsZUJ1aWxkZXI6IFNob3dIaWRlU3R5bGVCdWlsZGVyLCBzdHlsZXI6IFN0eWxlVXRpbHMsIG1hcnNoYWw6IE1lZGlhTWFyc2hhbGxlciwgbGF5b3V0Q29uZmlnOiBMYXlvdXRDb25maWdPcHRpb25zLCBwbGF0Zm9ybUlkOiBPYmplY3QsIHNlcnZlck1vZHVsZUxvYWRlZDogYm9vbGVhbik7XG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQ7XG4gICAgLyoqXG4gICAgICogT24gY2hhbmdlcyB0byBhbnkgQElucHV0IHByb3BlcnRpZXMuLi5cbiAgICAgKiBEZWZhdWx0IHRvIHVzZSB0aGUgbm9uLXJlc3BvbnNpdmUgSW5wdXQgdmFsdWUgKCdmeFNob3cnKVxuICAgICAqIFRoZW4gY29uZGl0aW9uYWxseSBvdmVycmlkZSB3aXRoIHRoZSBtcS1hY3RpdmF0ZWQgSW5wdXQncyBjdXJyZW50IHZhbHVlXG4gICAgICovXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQ7XG4gICAgLyoqXG4gICAgICogIFdhdGNoIGZvciB0aGVzZSBleHRyYSB0cmlnZ2VycyB0byB1cGRhdGUgZnhTaG93LCBmeEhpZGUgc3R5bGluZ3NcbiAgICAgKi9cbiAgICBwcm90ZWN0ZWQgdHJhY2tFeHRyYVRyaWdnZXJzKCk6IHZvaWQ7XG4gICAgLyoqXG4gICAgICogT3ZlcnJpZGUgYWNjZXNzb3IgdG8gdGhlIGN1cnJlbnQgSFRNTEVsZW1lbnQncyBgZGlzcGxheWAgc3R5bGVcbiAgICAgKiBOb3RlOiBTaG93L0hpZGUgd2lsbCBub3QgY2hhbmdlIHRoZSBkaXNwbGF5IHRvICdmbGV4JyBidXQgd2lsbCBzZXQgaXQgdG8gJ2Jsb2NrJ1xuICAgICAqIHVubGVzcyBpdCB3YXMgYWxyZWFkeSBleHBsaWNpdGx5IHNwZWNpZmllZCBpbmxpbmUgb3IgaW4gYSBDU1Mgc3R5bGVzaGVldC5cbiAgICAgKi9cbiAgICBwcm90ZWN0ZWQgZ2V0RGlzcGxheVN0eWxlKCk6IHN0cmluZztcbiAgICAvKiogVmFsaWRhdGUgdGhlIHZpc2liaWxpdHkgdmFsdWUgYW5kIHRoZW4gdXBkYXRlIHRoZSBob3N0J3MgaW5saW5lIGRpc3BsYXkgc3R5bGUgKi9cbiAgICBwcm90ZWN0ZWQgdXBkYXRlV2l0aFZhbHVlKHZhbHVlPzogYm9vbGVhbiB8IHN0cmluZyk6IHZvaWQ7XG59XG4vKipcbiAqICdzaG93JyBMYXlvdXQgQVBJIGRpcmVjdGl2ZVxuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBEZWZhdWx0U2hvd0hpZGVEaXJlY3RpdmUgZXh0ZW5kcyBTaG93SGlkZURpcmVjdGl2ZSB7XG4gICAgcHJvdGVjdGVkIGlucHV0czogc3RyaW5nW107XG59XG4iXX0=
/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
import { ElementRef } from '@angular/core';
import { MediaMarshaller, BaseDirective2, StyleBuilder, StyleDefinition, StyleUtils } from 'src/app/crud-grid/content/flex-layout/core';
import * as ɵngcc0 from '@angular/core';
export declare class ImgSrcStyleBuilder extends StyleBuilder {
    buildStyles(url: string): {
        content: string;
    };
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ImgSrcStyleBuilder, never>;
}
export declare class ImgSrcDirective extends BaseDirective2 {
    protected platformId: Object;
    protected serverModuleLoaded: boolean;
    protected DIRECTIVE_KEY: string;
    protected defaultSrc: string;
    set src(val: string);
    constructor(elementRef: ElementRef, styleBuilder: ImgSrcStyleBuilder, styler: StyleUtils, marshal: MediaMarshaller, platformId: Object, serverModuleLoaded: boolean);
    /**
     * Use the [responsively] activated input value to update
     * the host img src attribute or assign a default `img.src=''`
     * if the src has not been defined.
     *
     * Do nothing to standard `<img src="">` usages, only when responsive
     * keys are present do we actually call `setAttribute()`
     */
    protected updateWithValue(value?: string): void;
    protected styleCache: Map<string, StyleDefinition>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ImgSrcDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<ImgSrcDirective, never, never, { "src": "src"; }, {}, never>;
}
/**
 * This directive provides a responsive API for the HTML <img> 'src' attribute
 * and will update the img.src property upon each responsive activation.
 *
 * e.g.
 *      <img src="defaultScene.jpg" src.xs="mobileScene.jpg"></img>
 *
 * @see https://css-tricks.com/responsive-images-youre-just-changing-resolutions-use-src/
 */
export declare class DefaultImgSrcDirective extends ImgSrcDirective {
    protected inputs: string[];
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DefaultImgSrcDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<DefaultImgSrcDirective, "  img[src.xs],    img[src.sm],    img[src.md],    img[src.lg],   img[src.xl],  img[src.lt-sm], img[src.lt-md], img[src.lt-lg], img[src.lt-xl],  img[src.gt-xs], img[src.gt-sm], img[src.gt-md], img[src.gt-lg]", never, { "src.xs": "src.xs"; "src.sm": "src.sm"; "src.md": "src.md"; "src.lg": "src.lg"; "src.xl": "src.xl"; "src.lt-sm": "src.lt-sm"; "src.lt-md": "src.lt-md"; "src.lt-lg": "src.lt-lg"; "src.lt-xl": "src.lt-xl"; "src.gt-xs": "src.gt-xs"; "src.gt-sm": "src.gt-sm"; "src.gt-md": "src.gt-md"; "src.gt-lg": "src.gt-lg"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW1nLXNyYy5kLnRzIiwic291cmNlcyI6WyJpbWctc3JjLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBHb29nbGUgTExDIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9hbmd1bGFyLmlvL2xpY2Vuc2VcbiAqL1xuaW1wb3J0IHsgRWxlbWVudFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTWVkaWFNYXJzaGFsbGVyLCBCYXNlRGlyZWN0aXZlMiwgU3R5bGVCdWlsZGVyLCBTdHlsZURlZmluaXRpb24sIFN0eWxlVXRpbHMgfSBmcm9tICdAYW5ndWxhci9mbGV4LWxheW91dC9jb3JlJztcbmV4cG9ydCBkZWNsYXJlIGNsYXNzIEltZ1NyY1N0eWxlQnVpbGRlciBleHRlbmRzIFN0eWxlQnVpbGRlciB7XG4gICAgYnVpbGRTdHlsZXModXJsOiBzdHJpbmcpOiB7XG4gICAgICAgIGNvbnRlbnQ6IHN0cmluZztcbiAgICB9O1xufVxuZXhwb3J0IGRlY2xhcmUgY2xhc3MgSW1nU3JjRGlyZWN0aXZlIGV4dGVuZHMgQmFzZURpcmVjdGl2ZTIge1xuICAgIHByb3RlY3RlZCBwbGF0Zm9ybUlkOiBPYmplY3Q7XG4gICAgcHJvdGVjdGVkIHNlcnZlck1vZHVsZUxvYWRlZDogYm9vbGVhbjtcbiAgICBwcm90ZWN0ZWQgRElSRUNUSVZFX0tFWTogc3RyaW5nO1xuICAgIHByb3RlY3RlZCBkZWZhdWx0U3JjOiBzdHJpbmc7XG4gICAgc2V0IHNyYyh2YWw6IHN0cmluZyk7XG4gICAgY29uc3RydWN0b3IoZWxlbWVudFJlZjogRWxlbWVudFJlZiwgc3R5bGVCdWlsZGVyOiBJbWdTcmNTdHlsZUJ1aWxkZXIsIHN0eWxlcjogU3R5bGVVdGlscywgbWFyc2hhbDogTWVkaWFNYXJzaGFsbGVyLCBwbGF0Zm9ybUlkOiBPYmplY3QsIHNlcnZlck1vZHVsZUxvYWRlZDogYm9vbGVhbik7XG4gICAgLyoqXG4gICAgICogVXNlIHRoZSBbcmVzcG9uc2l2ZWx5XSBhY3RpdmF0ZWQgaW5wdXQgdmFsdWUgdG8gdXBkYXRlXG4gICAgICogdGhlIGhvc3QgaW1nIHNyYyBhdHRyaWJ1dGUgb3IgYXNzaWduIGEgZGVmYXVsdCBgaW1nLnNyYz0nJ2BcbiAgICAgKiBpZiB0aGUgc3JjIGhhcyBub3QgYmVlbiBkZWZpbmVkLlxuICAgICAqXG4gICAgICogRG8gbm90aGluZyB0byBzdGFuZGFyZCBgPGltZyBzcmM9XCJcIj5gIHVzYWdlcywgb25seSB3aGVuIHJlc3BvbnNpdmVcbiAgICAgKiBrZXlzIGFyZSBwcmVzZW50IGRvIHdlIGFjdHVhbGx5IGNhbGwgYHNldEF0dHJpYnV0ZSgpYFxuICAgICAqL1xuICAgIHByb3RlY3RlZCB1cGRhdGVXaXRoVmFsdWUodmFsdWU/OiBzdHJpbmcpOiB2b2lkO1xuICAgIHByb3RlY3RlZCBzdHlsZUNhY2hlOiBNYXA8c3RyaW5nLCBTdHlsZURlZmluaXRpb24+O1xufVxuLyoqXG4gKiBUaGlzIGRpcmVjdGl2ZSBwcm92aWRlcyBhIHJlc3BvbnNpdmUgQVBJIGZvciB0aGUgSFRNTCA8aW1nPiAnc3JjJyBhdHRyaWJ1dGVcbiAqIGFuZCB3aWxsIHVwZGF0ZSB0aGUgaW1nLnNyYyBwcm9wZXJ0eSB1cG9uIGVhY2ggcmVzcG9uc2l2ZSBhY3RpdmF0aW9uLlxuICpcbiAqIGUuZy5cbiAqICAgICAgPGltZyBzcmM9XCJkZWZhdWx0U2NlbmUuanBnXCIgc3JjLnhzPVwibW9iaWxlU2NlbmUuanBnXCI+PC9pbWc+XG4gKlxuICogQHNlZSBodHRwczovL2Nzcy10cmlja3MuY29tL3Jlc3BvbnNpdmUtaW1hZ2VzLXlvdXJlLWp1c3QtY2hhbmdpbmctcmVzb2x1dGlvbnMtdXNlLXNyYy9cbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgRGVmYXVsdEltZ1NyY0RpcmVjdGl2ZSBleHRlbmRzIEltZ1NyY0RpcmVjdGl2ZSB7XG4gICAgcHJvdGVjdGVkIGlucHV0czogc3RyaW5nW107XG59XG4iXX0=
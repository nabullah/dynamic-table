/**
 * *****************************************************************
 * Define module for the Extended API
 * *****************************************************************
 */
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './show-hide/show-hide';
import * as ɵngcc2 from './class/class';
import * as ɵngcc3 from './style/style';
import * as ɵngcc4 from './img-src/img-src';
import * as ɵngcc5 from 'src/app/crud-grid/content/flex-layout/core';
export declare class ExtendedModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<ExtendedModule, [typeof ɵngcc1.DefaultShowHideDirective, typeof ɵngcc2.DefaultClassDirective, typeof ɵngcc3.DefaultStyleDirective, typeof ɵngcc4.DefaultImgSrcDirective], [typeof ɵngcc5.CoreModule], [typeof ɵngcc1.DefaultShowHideDirective, typeof ɵngcc2.DefaultClassDirective, typeof ɵngcc3.DefaultStyleDirective, typeof ɵngcc4.DefaultImgSrcDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<ExtendedModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbIm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiBEZWZpbmUgbW9kdWxlIGZvciB0aGUgRXh0ZW5kZWQgQVBJXG4gKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBFeHRlbmRlZE1vZHVsZSB7XG59XG4iXX0=